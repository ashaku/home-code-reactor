<?
	// Skill Classes
	// Represent any monster skill
	// It has a list of effects
	// Effects are basic action : deal damage, heal, buff, debuff, etc
	include ("skillFactory.php");
	
	// Global object Skill : name, list of effects and cooldown
	class Skill{
		private $name;
		private $effects;	// SkillAction
		private $cooldown;	// int
		private $active;	// bool
	
		function __construct($aNom,$aEffects,$aCooldown,$aActive) {
			$this->name = $aNom;
			$this->effects = $aEffects;
			$this->cooldown = $aCooldown;
			$this->active = $aActive;
		}
		public function get_name(){			return $this->name;		}
		public function get_effects(){		return $this->effects;	}
		public function get_cooldown(){		return $this->cooldown;	}
		public function is_active(){		return $this->active;	}
	}
	
	// General Skill effect : type of effect and targetting infos
	abstract class SkillEffect{
		private $type;			// SKILLEFFECT
		private $targetSide; 	// 0:ennemy ; 1:ally
		private $targetZone;	// 0:unique ; 1:multi ; 2:all
		private $targetNbMulti;	// if zone=multi
		
		function __construct($aType,$aSide,$aZone,$aNbMulti=0 ) {
			$this->type = $aType;
			$this->targetSide = $aSide;
			$this->targetZone = $aZone;
			$this->targetNbMulti = $aNbMulti;
		}
		
		public function get_type(){				return $this->type;				}
		public function get_targetSide(){		return $this->targetSide;		}
		public function get_targetZone(){		return $this->targetZone;		}
		public function get_targetNbMulti(){	return $this->targetNbMulti;	}
		public function execute(){}
	}
	
	// Specific effect Damage
	class Damage extends SkillEffect{
		private $formula;
		private $nbHits;
		private $ignoreDef;
		
		function __construct($aZone,$aFormula,$aType=EFFECT::damage,$aNbHits=1,$aIgnoreDef=false){
			parent::__construct($aType,TARGET::ENNEMY,$aZone);
			$this->formula = $aFormula;
			$this->nbHits = $aNbHits;
			$this->ignoreDef = $aIgnoreDef;
		}
		
		public function get_nbHits(){	return $this->nbHits;		}
		public function ignore_def(){	return $this->ignoreDef;	}
		
		public function execute($attackingMonsterStats){
			// decode formula
			$operand1 = 0;
			$operand2 = 0;
			$operator1 = "";
			$operator2 = "";
			$total = 0;
			//echo "<br><br>Start Decode Formula : ";print_r($this->formula);
			foreach($this->formula as $i => $line){
				//echo "<br> &nbsp; line $i : ";print_r($line);
				
				// for operand
				if ( $i % 2 == 0 ){
					
					// If unique value
					if ( count($line) == 1 ){
						// decode stat
						$data = $line[0];
						//echo "<br> &nbsp; Unique value : ".$data;
						if ( !is_numeric($data) ){
							switch($data){
								case "HP": $lineVal = $attackingMonsterStats[STATS::HP];	break;
								case "ATK": $lineVal = $attackingMonsterStats[STATS::ATK];	break;
								case "DEF": $lineVal = $attackingMonsterStats[STATS::DEF];	break;
								case "SPD": $lineVal = $attackingMonsterStats[STATS::SPD];	break;
								case "MAXHP": $lineVal = $attackingMonsterStats[STATS::MAXHP];	break;
							}
							//echo " => ".$lineVal;
						}else{
							$lineVal = $data;
						}
						
						
					// If operand is formula itself : apply same logic on a second level
					}else{
						
						$lineVal = 0;
						//echo "<br> &nbsp; Array value : compute";
						foreach($line as $j => $data){
							//echo "<br> &nbsp; &nbsp; $j. $data";
							
							if ( $j % 2 == 0 ){
								//operand
								//decode stat
								if ( !is_numeric($data) ){
									switch($data){
										case "HP": $numval = $attackingMonsterStats[STATS::HP];		break;
										case "ATK": $numval = $attackingMonsterStats[STATS::ATK];	break;
										case "DEF": $numval = $attackingMonsterStats[STATS::DEF];	break;
										case "SPD": $numval = $attackingMonsterStats[STATS::SPD];	break;
										case "MAXHP": $numval = $attackingMonsterStats[STATS::MAXHP];	break;
									}
									//echo " => ".$numval;
								}else{
									$numval = $data;
								}
								if ( $j == 0 ){
									//store first
									$lineVal = $numval;
									//echo " :: Store $numval as first subline value";
								}else{
									//calculate next
									//echo " :: Compute $lineVal ";
									switch ($operator2){
										case "+": $lineVal += $numval; break;
										case "-": $lineVal -= $numval; break;
										case "*": $lineVal *= $numval; break;
										case "/": $lineVal /= $numval; break;
										case "%": $lineVal = $lineVal * $numval / 100; break;
									}
									//echo " => $lineVal";
								}
							}else{
								$operator2 = $data;
								//echo " :: update operator2";
							}
						}
					}
					
					// If first value
					if ( $i == 0 ){
						
						// store
						$total = $lineVal;
						//echo "<br> &nbsp; Store $lineVal as first line value";
					}else{
						
						// For next values : update total with last operand and current operand
						//echo "<br> &nbsp; Compute $total ";
						switch ($operator1){
							case "+": $total += $lineVal; break;
							case "-": $total -= $lineVal; break;
							case "*": $total *= $lineVal; break;
							case "/": $total /= $lineVal; break;
							case "%": $total = $total * $lineVal / 100; break;
						}
						//echo " => $total";
					}
				
				// for operator
				}else{
					// simply store it
					$operator1 = $line[0];
					//echo " update operator1";
				}
			}
			//echo "<br> => total damage : ".round ( $total );
			return round ( $total );
		}
	}
	
	// Specific effect : damage and debuff the target
	class DamageDebuff extends Damage{
		private $debuffType;
		private $nbTurns;
		private $perCent;
		
		function __construct($aZone,$aFormula,$aDebuffType,$aNbTurns,$aPerCent,$aNbHits=1,$aIgnoreDef=false){
			parent::__construct($aZone,$aFormula,EFFECT::damageDebuff,$aNbHits,$aIgnoreDef);
			$this->debuffType = $aDebuffType;
			$this->nbTurns = $aNbTurns;
			$this->perCent = $aPerCent;
		}
		
		public function execute($attackingMonsterStats){
			$dmg = parent::execute($attackingMonsterStats);
			return array($dmg,$this->perCent,$this->debuffType,$this->nbTurns);
		}
	}
	
	// Specfic effect : damage and strip the target
	class DamageStrip extends Damage{
		private $nbBuffToStrip;	// 0:all ; n:n
		
		function __construct($aZone,$aFormula,$nbBuffToStrip,$aNbHits=1){
			parent::__construct($aZone,$aFormula,EFFECT::damageStrip,$aNbHits);
			$this->nbBuffToStrip = $nbBuffToStrip;
		}
		
		public function execute($attackingMonsterStats){
			$dmg = parent::execute($attackingMonsterStats);
			return array($dmg,$this->nbBuffToStrip);
		}
	}
	
	// Generic class for specific effect that only need to store and give information
	// used for : cleanse, heal, strip, raiseAtkBar, lowAtkBar
	class SingleEffect extends SkillEffect{
		private $value;	// a single value to store and give
		function __construct($aZone,$aEffectType,$aTargetSide,$aValue){
			parent::__construct($aEffectType,$aTargetSide,$aZone);
			$this->value = $aValue;
		}
		public function execute(){
			return $this->value;
		}
	}
	
	
?>
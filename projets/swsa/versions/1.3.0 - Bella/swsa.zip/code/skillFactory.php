<?
	// Skill Factory : give the name, receive the skill object
	abstract class SkillLib{
		public function load_skill ( $name ){
			switch($name){
				
				// Veromos
				case "MegaSmash":
					$skillName = "Mega Smash";
					$targetZone = TARGET::UNIQUE;
					$dmgFormula = array(array("SPD","+",210),array("/"),array(0.7),array("%"),array("ATK"));
					$nbHits = 1;
					$debuffType = DEBUFF::CONSTDMG;
					$nbTurns = 2;
					$perCent = 75;
					$constDamageEffect = new DamageDebuff($targetZone,$dmgFormula,$debuffType,$nbTurns,$perCent,$nbHits);
					$skillEffects = array($constDamageEffect);
					$skillCooldown = 1;
					$active = true;
					break;
					
				case "SuperCrush":
					$skillName = "Super Crush";
					$targetZone = TARGET::ALL;
					$dmgFormula = array(array(16,"%","MAXHP"),array("+"),array(140,"%","ATK"));
					$debuffType = DEBUFF::STUN;
					$nbTurns = 1;
					$perCent = 60;
					$StunDamageEffect = new DamageDebuff($targetZone,$dmgFormula,$debuffType,$nbTurns,$perCent,$nbHits);
					$skillEffects = array($StunDamageEffect);
					$skillCooldown = 3;
					$active = true;
					break;
					
				case "ConversionOfMagic":
					$skillName = "Conversion of magic";
					$targetZone = TARGET::ALL;
					$targetSide = TARGET::ALLIES;
					$effectType = EFFECT::cleanse;
					$nbCleanse = 1;		// 0:all ; n:n
					$cleanseEffect = new SingleEffect($targetZone,$effectType,$targetSide,$nbCleanse);
					$skillEffects = array($cleanseEffect);
					$skillCooldown = 1;
					$active = false;
					break;
				
				// Belladeon
				case "Scratch" :
					$skillName = "Scratch";
					$targetZone = TARGET::UNIQUE;
					$dmgFormula = array(array(400),array("%"),array("ATK"));
					$nbHits = 1;
					$debuffType = DEBUFF::LOWDEF;
					$nbTurns = 2;
					$perCent = 100;
					$lowdefDmgEffect = new DamageDebuff($targetZone,$dmgFormula,$debuffType,$nbTurns,$perCent,$nbHits);
					$skillEffects = array($lowdefDmgEffect);
					$skillCooldown = 1;
					$active = true;
					break;
					
				case "Seize" :
					$skillName = "Seize";
					$targetZone = TARGET::UNIQUE;
					$dmgFormula = array(array(580),array("%"),array("ATK"));
					$nbHits = 1;
					$nbStrip = 0;		// 0:all ; n:n
					$stripDmgEffect = new DamageStrip($targetZone,$dmgFormula,$nbStrip,$nbHits);
					$skillEffects = array($stripDmgEffect);
					$skillCooldown = 3;
					$active = true;
					break;
					
				case "Mobilize" :
					$skillName = "Mobilize";
					$targetZone = TARGET::ALL;
					$healAmount = 50;	// % of target max HP healed
					$effectType = EFFECT::heal;
					$targetSide = TARGET::ALLIES;
					$healEffect = new SingleEffect($targetZone,$effectType,$targetSide,$healAmount);
					$effectType = EFFECT::raiseAtkBar;
					$raiseAmount = 30;
					$raiseAtkBarEffect = new SingleEffect($targetZone,$effectType,$targetSide,$raiseAmount);
					$skillEffects = array($healEffect,$raiseAtkBarEffect);
					$skillCooldown = 4;
					$active = true;
					break;
					
				// Lushen
				case "flyingCards" :
					$skillName = "Flying cards";
					$targetZone = TARGET::UNIQUE;
					$dmgFormula = array(array(360),array("%"),array("ATK"));
					$nbHits = 1;
					$debuffType = DEBUFF::NOHEAL;
					$nbTurns = 2;
					$perCent = 70;
					$nohealDmgEffect = new DamageDebuff($targetZone,$dmgFormula,$debuffType,$nbTurns,$perCent,$nbHits);
					$skillEffects = array($nohealDmgEffect);
					$skillCooldown = 1;
					$active = true;
					break;
					
				case "surpriseBox" :
					$skillName = "surprise box";
					$targetZone = TARGET::ALL;
					$dmgFormula = array(array(240),array("%"),array("ATK"));
					$nbHits = 1;
					$debuffType = DEBUFF::LOWSPD;
					$nbTurns = 1;
					$perCent = 100;
					$nohealDmgEffect = new DamageDebuff($targetZone,$dmgFormula,$debuffType,$nbTurns,$perCent,$nbHits);
					$skillEffects = array($nohealDmgEffect);
					$skillCooldown = 4;
					$active = true;
					break;
				
				case "amputationOfMagic" :
					$skillName = "Amputation of magic";
					$targetZone = TARGET::ALL;
					$dmgFormula = array(array(68),array("%"),array("ATK"));
					$nbHits = 3;
					$ignoreDef = true;
					$nohealDmgEffect = new Damage($targetZone,$dmgFormula,EFFECT::damage,$nbHits,$ignoreDef);
					$skillEffects = array($nohealDmgEffect);
					$skillCooldown = 4;
					$active = true;
					break;
					
					
				/* SAMPLE :
				case "" :
					$skillName = "";
					$effect = new _effect_();
					$skillEffects = array($effect);
					$skillCooldown = 1;
					$active = true;
					break;
					*/
			}
			return new Skill($skillName,$skillEffects,$skillCooldown,$active);
		}
	}
?>
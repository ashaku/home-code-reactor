<?
	include ("constants.php");
	// include ("Skill.php");
	include ("Rune.php");
	
	class Monster{
		
		private $name;
		private $element;	// ELMT
		private $stats;		// STATS
		//private $skills = array();	
		private $runes;	
		private $statModifiers;
		
		function __construct($aNom,$aElement,$aStats,$aRunage) {
			$this->name = $aNom;
			if ( aElement >= 0 && $aElement <= 5 ){
				$this->element = $aElement;
			}
			if ( sizeof($aStats) == 8 ){
				$this->stats = $aStats;
			}
			/*if ( sizeof($aSkills) > 0 && sizeof($aSkills) < 5 ){
				$this->skills = $aSkills;
			*/
			$runage = new Runage($aRunage);
			$this->runes = $runage;
			
			$this->calculate_stats_modifiers();
		}
		
		public function get_name(){		return $this->name;				}
		public function get_element(){	return $this->element;			}
		public function get_stats(){	return $this->stats;			}
		public function get_statsMod(){	return $this->statModifiers;	}
		
		// Aggregate bonus from runage (family + sub)
		private function calculate_stats_modifiers(){
			$this->statModifiers = array(0,0,0,0,0,0,0,0);
			// Each runageSubBonus
			$i = 0;
			foreach($this->runes->get_stats_modifiers() as $mod){
				$s = floor($i/2);
				if ( $i % 2 == 0 || $s > 3 ){
					$this->statModifiers[$s] += $mod;
				}else{
					$pc = round( $mod * $this->stats[$s] / 100 );
					$this->statModifiers[$s] += $pc;
				}
				$i++;
			}
			// Each runageFamilyBonus
			$i = 0;
			foreach($this->runes->get_family_modifiers() as $mod){
				$s = floor($i/2);
				if ( $i % 2 == 0 || $i > 3 ){
					$this->statModifiers[$s] += $mod;
				}else{
					$pc = round( $mod * $this->stats[$s] / 100 );
					$this->statModifiers[$s] += $pc;
				}
				$i++;
			}
		}
		
		public function display(){
			echo "
				<div class='monsterID'>
					<b>".$this->name."</b><br>
					<span>(".ELMT::get_name($this->element).")</span>
					<br><br>
					<table cellspacing=0 border=0 width=100%>";
			// Stats
			for ($i=0;$i<4;$i++){
				echo "
					<tr>
						<td title='".STATS::get_long_name($i)."' class='statName'>".STATS::get_short_name($i)."</td><td class='statVal'>".$this->stats[$i]."</td><td class='statMod'>+".$this->statModifiers[$i]."</td>
						<td title='".STATS::get_long_name($i+4)."' class='statName'>".STATS::get_short_name($i+4)."</td><td class='statVal'>".($this->stats[$i+4]+$this->statModifiers[$i+4])."</td><td class='statMod'>&nbsp;</td>
					</tr>";
			}
			echo "
					</table>
					<br><br>";
			// Runes
			$this->runes->display();
			echo"
				</div>";
		}
	}
	
	
	
?>
<?
	// Constant classes
	// Act like enum for clarity in code
	
	class ELMT{
		const water = 0;
		const fire = 1;
		const wind = 2;
		const dark = 3;
		const light = 4;
		
		public static function get_name($aElmtID){
			$tabElmtNames = array("water","fire","wind","dark","light");
			return $tabElmtNames[$aElmtID];
		}
	}
	
	class STATS{
		const HP = 0;
		const ATK = 1;
		const DEF = 2;
		const SPD = 3;
		const CR = 4;
		const CD = 5;
		const PRE = 6;
		const RES = 7;
		
		public static function get_long_name($aStatID){
			$tabStatsNames = array("HP","Attack","Defense","Speed","Critical Rate","Critical Damage","Precision","Resistance");
			return $tabStatsNames[$aStatID];
		}
		public static function get_short_name($aStatID){
			$tabStatsShortNames = array("HP","ATK","DEF","SPD","CR","CD","PRE","RES");
			return $tabStatsShortNames[$aStatID];
		}
	}
	
	
	/*
	class SKLEFCT{
		const damage = 0;
		const heal = 1;
		const buff = 2;
		const debuff = 3;
		const strip = 4;
		const cleanse = 5;
		
		public static function get_name($aSkillTypeID){
			$tabSkillsNames = array("damage","heal","buff","debuff","strip","cleanse");
			return $tabSkillsNames[$aSkillTypeID];
		}
	}
	*/
	
	class RUNEFAMILY{
		const Energy = 0;
		const Guard = 1;
		const Blade = 2;
		const Focus = 3;
		const Endure = 4;
		const Nemesis = 5;
		const Will = 6;
		const Shield = 7;
		const Revenge = 8;
		const Destroy = 9;
		const Swift = 10;
		const Rage = 11;
		const Fatal = 12;
		const Despair = 13;
		const Vampire = 14;
		const Violent = 15;
		/*const Protection = 16;
		const Energy = 17;
		const Energy = 18;
		const Energy = 19;*/
		
		public static function get_name($aFamilyID){
			$tabFamilyNames = array("Energy","Guard","Blade","Focus","Endure","Nemesis","Will","Shield","Revenge","Destroy","Swift","Rage","Fatal","Despair","Vampire","Violent");
			return $tabFamilyNames[$aFamilyID];
		}
	}
	
?>
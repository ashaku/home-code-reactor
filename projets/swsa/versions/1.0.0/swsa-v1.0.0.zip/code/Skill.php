<?
	// Skill Classes
	// Represent any monster skill
	
	class Skill{
		private $name;
		private $mode;	// 0:passive ; 1:active
		private $side; 	// 0:ennemy ; 1:ally
		private $target; // 0:unique ; 1:multi ; 2:all
		private $actions;
	
		function __construct($aNom,$aMode,$aSide,$aTarget,$aActions) {
			$this->name = $aNom;
			$this->mode = $aMode;
			$this->side = $aSide;
			$this->target = $aTarget;
			$this->actions = $aActions;
		}
		public function get_name(){
			return $this->name;
		}
		public function get_mode(){
			return $this->mode;
		}
		public function get_side(){
			return $this->side;
		}
		public function get_target(){
			return $this->target;
		}
		public function get_actions(){
			return $this->actions;
		}
	}
	
	class SkillAction{
		private $type; // SKLEFCT
	}
?>
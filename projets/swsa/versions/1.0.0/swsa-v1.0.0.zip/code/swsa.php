<?
	include('Monster.php');
?>

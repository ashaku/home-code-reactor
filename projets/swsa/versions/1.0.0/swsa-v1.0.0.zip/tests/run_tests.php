<? 
	// VISUALISATION DES TESTS

	require('../code/swsa.php');
	require('tests.php');
?>
<!DOCTYPE html>
<html lang='fr'>
	<head>
		<title>SWSA</title>
		<link rel="stylesheet" type="text/css" href="screen.css">
		<meta charset="utf-8">
	</head>
	<body>
	
<?
	$testRune = 0;
	$testRunage = 0;
	$testMon = 1;
	
	
	//$retTest = tf_runage();
	//print_r($retTest);
	
	
	// Test Rune
	if ( $testRune ){
		/*
		$runeCode = "";
		for ( $i=0; $i<36; $i++ )	$runeCode .= mt_rand(0,1);
		$runePosition=mt_rand(1,6);
		$runeMain = -1;
		if ( $runePosition == 2 )
			$runeMain = mt_rand(0,3);
		elseif ( $runePosition == 4 || $runePosition == 6 )
			$runeMain = mt_rand(0,7);
		*/
		
		$rune1 = "000000000000000100000011000001000000";	// Energy / Atq+ / HP+ HP+% Atq+% Def+
		$rune2 = "000001010000100100001011000011010000";	// Energy / Vit+ / Def+% CR+% CD+% Pre+%
		$rune3 = "110011110000000000000001000000100000";	// Fatal / Def+ / Res+% HP+ HP+% Atq+
		$rune4 = "110000110000010000000101000001100000";	// Fatal / CR+% / Atq+% Def+ Def+% Vit+
		$rune5 = "110010010000101100001101000011110000";	// Fatal / HP+ / CR+% CD+% Pre+% Res+%
		$rune6 = "110000010000001000000011000001010000";	// Fatal / Pre+% / HP+% Atq+ Atq+% Def+%
		
		$runeCode = $rune6;
		$runePosition = 6;
		$runeMain = 6;
		
		display_rune_code($runeCode);
		echo "<br>";
		$rune = new Rune($runeCode,$runePosition,$runeMain);
		$rune->display_code();
		echo "<br>";
		$rune->display();
	}
	
	
	
	
	// Test runage
	if ( $testRunage ){
		
		// Runage test
		$mains = "11100110";	// SPD CR PRE
		$rune1 = "000000000000000100000011000001000000";	// Energy / Atq+ / HP+ HP+% Atq+% Def+
		$rune2 = "000001010000100100001011000011010000";	// Energy / Vit+ / Def+% CR+% CD+% Pre+%
		$rune3 = "110011110000000000000001000000100000";	// Fatal / Def+ / Res+% HP+ HP+% Atq+
		$rune4 = "110000110000010000000101000001100000";	// Fatal / CR+% / Atq+% Def+ Def+% Vit+
		$rune5 = "110010010000101100001101000011110000";	// Fatal / HP+ / CR+% CD+% Pre+% Res+%
		$rune6 = "110000010000001000000011000001010000";	// Fatal / Pre+% / HP+% Atq+ Atq+% Def+%
		$runageCode = $mains.$rune1.$rune2.$rune3.$rune4.$rune5.$rune6;
		
		echo "<br><br>RUNAGE TEST<br>";
		//echo "Code : ".$runageCode."<br>";
		$r = new Runage($runageCode);
		$r->display();
	}
	
	// Test Monstre
	if ( $testMon ){
		$name = "Veromos";
		$element = ELMT::dark;
		$stats = array(9225,769,758,100,15,50,0,15);
		//$skills = array();
		$runeCode = "";
		
		$mains = "11100110";	// SPD CR PRE
		$rune1 = "000000000000000100000011000001000000";	// Energy / Atq+ / HP+ HP+% Atq+% Def+
		$rune2 = "000001010000100100001011000011010000";	// Energy / Vit+ / Def+% CR+% CD+% Pre+%
		$rune3 = "110011110000000000000001000000100000";	// Fatal / Def+ / Res+% HP+ HP+% Atq+
		$rune4 = "110000110000010000000101000001100000";	// Fatal / CR+% / Atq+% Def+ Def+% Vit+
		$rune5 = "110010010000101100001101000011110000";	// Fatal / HP+ / CR+% CD+% Pre+% Res+%
		$rune6 = "110000010000001000000011000001010000";	// Fatal / Pre+% / HP+% Atq+ Atq+% Def+%
		$runeCode = $mains.$rune1.$rune2.$rune3.$rune4.$rune5.$rune6;
		
		// Aleatoire
		//for ( $i=0; $i<224; $i++ )	$runeCode .= mt_rand(0,1);
		$m = new Monster($name,$element,$stats,$runeCode);
		$m->display();
	}
	
	
	
	function display_rune_code($code){
		echo substr($code,0,4)." ".substr($code,4,8)." ".substr($code,12,8)." ".substr($code,20,8)." ".substr($code,28);
	}
		
?>

	<body>
</html>

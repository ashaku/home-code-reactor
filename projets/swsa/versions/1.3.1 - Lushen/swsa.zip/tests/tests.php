<?
	// LIBRAIRIE DES TESTS



	//////////////////////////////////////////////
	///////	RUNES, RUNAGE & CODE GENETIQUE	//////
	//////////////////////////////////////////////
	
	//Créé une rune 2 Energy / SPD+39 / CR+% CD+% PRE+% RES+% CR+% CD+% et vérifie que le code fourni est bien décodé
	function tu_rune_decode(){
		
		// Créer rune
		$position = 2;
		$family = RUNEFAMILY::Energy;
		$mainStat = STATS::SPD;
		$code = "100101110111100101";
		$r = new Rune($position,$family,$mainStat,$code);
		
		// Verifier modifiers
		$defBonus = $r->get_defaultBonus();
		foreach ( $r->get_statsModifiers() as $statIndex=>$value ){
			switch ($statIndex){
				case 6 : if ( $value != 39 ) return array(false,"modificateur SPD incorrect ($value au lieu de 39)");	break;
				case 9 : if ( $value != 2*$defBonus ) return array(false,"modificateur CR incorrect ($value au lieu de ".(2*$defBonus).")");	break;
				case 11 : if ( $value != 2*$defBonus ) return array(false,"modificateur CD incorrect ($value au lieu de ".(2*$defBonus).")");	break;
				case 13 : if ( $value != $defBonus ) return array(false,"modificateur PRE incorrect ($value au lieu de ".$defBonus.")");	break;
				case 15 : if ( $value != $defBonus ) return array(false,"modificateur RES incorrect ($value au lieu de ".$defBonus.")");	break;
				default : if ( $value != 0 ) return array(false,"modificateur ".$statIndex." incorrect ($value au lieu de 0)");	break;
			}
		}
		
		// Verifier main
		$m = $r->get_mainStat();
		$ms = STATS::get_short_name($m->get_stat());
		if ( $ms != "SPD" )	return array(false,"stat main incorrecte ($ms au lieu de SPD)");
		$mt = $m->get_type();
		if ( $mt != "0" )	return array(false,"type main incorrect ($mt au lieu de 0)");
		$mv = $m->get_value();
		if ( $mv != 39 )	return array(false,"valeur main incorrecte ($mv au lieu de 39)");
		
		// Verifier sub
		$s = $r->get_subStats();
		$b = $r->get_defaultBonus();
		$i = 4;
		foreach ( $s as $sub ){
			if ( $i>7 ) $i=4;
			$ms = $sub->get_stat();
			if ( $ms != $i )	return array(false,"stat sub ".($i-3)." incorrecte ($ms au lieu de $i)");
			$mt = $sub->get_type();
			if ( $mt != "1" )	return array(false,"type sub ".($i-3)." incorrect ($mt au lieu de 1)");
			$mv = $sub->get_value();
			if ( $mv != $b )	return array(false,"valeur sub ".($i-3)." incorrect ($mv au lieu de $b)");
			$i++;
		}
		
		// Vérifier code binaire
		$c = $r->get_code();
		if ( $c != $code )	return array(false,"Erreur decode : code binaire modifié ($c au lieu de $code)");
		
		return array(true,"OK");
	}
	
	//Créé une rune avec 2 sub identiques au main et vérifie leur correction
	function tu_rune_correct(){
		// Créer une rune avec un sub en double
		// Energy Main:PV+51% Sub:PV+% ATK+% ATK+% DEF+% SPD+ HP+%
		$position = 2;
		$family = RUNEFAMILY::Energy;
		$mainStat = STATS::HP;
		$code = "000001001010011000";
		$r = new Rune($position,$family,$mainStat,$code);
		
		// Verifie que les stat en erreur a changé
		$s = $r->get_subStats();
		if ( $s[0]->get_stat() == STATS::HP )	return array(false,"La sub 1 en doublon du main est inchangée");
		if ( $s[5]->get_stat() == STATS::HP )	return array(false,"La sub 6 en doublon du main est inchangée");
		
		// Verifie que la main stat n est pas comptée en double
		$mods = $r->get_statsModifiers();
		if ( $mods[1] != 51 )	return array(false,"La main stat a été comptée en double dans les modificateurs : ".$mods[1]." au lieu de 51");
		
		// Verifie que le code binaire de la rune a changé
		$newRuneCode = $r->get_code();
		if ( $newRuneCode == $code )	return array(false,"Le code binaire est inchangé");
		
		return array(true,"OK");
	}
	
	//Créé deux runes avec toutes les stats possibles en sub et vérifie les modificateurs (somme de tous les bonus) 
	function tu_rune_modifiers(){
		
		// Rune 1 : Main:Atk+99 Sub:HP+% ATK+% DEF+% SPD+ CD+% RES+%
		$position = 1;
		$family = RUNEFAMILY::Energy;
		$code = "000001010011101111";
		$r = new Rune($position,$family,-1,$code);
		$mods = $r->get_statsModifiers();
		$b = $r->get_defaultBonus();
		foreach ( $mods as $modIndex=>$value ){
			switch ($modIndex ){
				case 2 :	if ( $value != 99 )	return array(false,"modificateur $modIndex incorrect : ".$value." au lieu de 99");	break;
				case 1 :	case 3 :		case 5 :	case 6 :	case 11 :	case 15:	
							if ( $value != $b )	return array(false,"modificateur $modIndex incorrect : ".$value." au lieu de $b");	break;
				default :	if ( $value != 0 )	return array(false,"modificateur $modIndex incorrect : ".$value." au lieu de 0");	break;
			}
		}
		
		return array(true,"OK");
	}
	
	
	
	//Créé 6 runes à partir d un set prédéfini et vérifie les modificateurs (famille + bonus)
	function tf_runage(){
		$mains = "11011011";	// SPD CR PRE
		$families = "0000000100000";	// 4 fatale 2 energy
		$rune1 = "100101110111100101";	// CR CD Pre Res CR CD
		$rune2 = "100101110111100101";	// CR CD Pre Res CR CD
		$rune3 = "000001010011000001";	// HP Atq Def Vit HP Atq
		$rune4 = "000001010011000001";	// HP Atq Def Vit HP Atq
		$rune5 = "100101110111100101";	// CR CD Pre Res CR CD
		$rune6 = "000001010011000001";	// HP Atq Def Vit HP Atq
		$runageCode = $mains.$families.$rune1.$rune2.$rune3.$rune4.$rune5.$rune6;
		$runage = new Runage($runageCode);
		
		// Calculer chiffres attendus
		$r=new Rune(1,0,0,"");
		$defVal = $r->get_defaultBonus();
		$expectedModifiers = array(1530,$defVal*6,99,$defVal*6,99,$defVal*3,39+$defVal*3,0,0,$defVal*6,0,65+$defVal*6,0,51+$defVal*3,0,$defVal*3);
		$statMod = $runage->get_stats_modifiers();
		for ( $i=0; $i<16; $i++ ){
			if ( $statMod[$i] != $expectedModifiers[$i] )	return array(false,"Erreur sub, modificateur $i : ".$statMod[$i]." au lieu de ".$expectedModifiers[$i]);
		}
		
		$expectedModifiers = array(0,15,0,35,0,0,0,0,0,0,0,0,0,0,0,0);
		$statMod = $runage->get_family_modifiers();
		for ( $i=0; $i<16; $i++ ){
			if ( $statMod[$i] != $expectedModifiers[$i] )	return array(false,"Erreur family, modificateur $i : ".$statMod[$i]." au lieu de ".$expectedModifiers[$i]);
		}
		
		return array(true,"OK");
	}
	
	
	
	
	
	//////////////////////////////////////////////
	////////////	MONSTRE		//////////////////
	//////////////////////////////////////////////
	
	//Créé un monstre avec son runage et vérifie ses stats avec runes et leader skill
	function tu_monstre_stats(){
		
		$name = "Veromos";
		$mains = "11011011";	// SPD CR PRE
		$families = "0000000100000";	// 4 fatale 2 energy
		$rune1 = "100101110111100101";	// CR CD Pre Res CR CD
		$rune2 = "100101110111100101";	// CR CD Pre Res CR CD
		$rune3 = "000001010011000001";	// HP Atq Def Vit HP Atq
		$rune4 = "000001010011000001";	// HP Atq Def Vit HP Atq
		$rune5 = "100101110111100101";	// CR CD Pre Res CR CD
		$rune6 = "000001010011000001";	// HP Atq Def Vit HP Atq
		$runeCode = $mains.$families.$rune1.$rune2.$rune3.$rune4.$rune5.$rune6;
		$monster = MonsterLib::load_monster($name,$runeCode);
		$monStats = $monster->get_base_stats();
		
		// RuneStats
		$r=new Rune(1,0,0,"");
		$defVal = $r->get_defaultBonus();
		$hpRune = 1531 + round($monStats[0]*($defVal*6+15)/100);
		$expectedModifiers = array(	$hpRune,
									99 + round($monStats[1]*($defVal*6+35)/100),
									99 + round($monStats[2]*$defVal*3/100),
									39 + round($monStats[3]*$defVal*3/100),
									$defVal*6,
									65 + $defVal*6,
									51 + $defVal*3,
									$defVal*3);
		$statMod = $monster->get_runes_mod();
		for ( $i=0; $i<8; $i++ ){
			if ( $statMod[$i] != $expectedModifiers[$i] )	return array(false,"Erreur modificateur $i : ".$statMod[$i]." au lieu de ".$expectedModifiers[$i]);
		}
		
		// LeadSkill
		$expectedHP = round($monStats[0]*0.33) + $hpRune + $monStats[0];
		$leadSkill = $monster->get_leadSkill();
		$monster->add_leader_skill_bonus($leadSkill);
		$newHp = $monster->get_runes_stat(STATS::HP);
		if ( $newHp != $expectedHP )	return array(false,"Erreur Leader Skill, HP = ".$newHp." au lieu de ".$expectedHP);
		
		return array(true,"OK");
	}
	
	
	//Créé Veromos avec un buff et un debuff atk, lui fait lancer ses 2 sorts et vérifie le cooldown des sorts et des buffs/debuffs
	function tf_monstre_cooldown(){
		
		$runeCode = "110110110000000100000100101110111100101100101110111100101000001010011000001000001010011000001100101110111100101000001010011000001";
		$monster = MonsterLib::load_monster("Veromos",$runeCode);
		
		$nbTours = 3;
		$debuffAtk = array("perCent"=>50,"type"=>DEBUFF::LOWATK,"turns"=>$nbTours);
		$buffAtk = array("perCent"=>50,"type"=>BUFF::RAISEATK,"turns"=>$nbTours);
		
		$monster->add_debuff($debuffAtk);
		$monster->add_buff($buffAtk);
		
		// Launch super crush
		$monster->choose_skill(1);
		// Check skill countdown
		$cdMegaSmash = $monster->get_cooldowns()[0];
		$cdSuperCrush = $monster->get_cooldowns()[1];
		if ( $cdMegaSmash != 0 ) return array(false,"Le sort mega smash devrait etre en cooldown pour 0 tour, pas ".$cdMegaSmash);
		if ( $cdSuperCrush != 3 ) return array(false,"Le sort super crush devrait etre en cooldown pour 3 tours, pas ".$cdSuperCrush);
		
		// Cooldown
		// Skill:4=>3 ; BUFF:3=>2 ; DEBUFF:3=>2
		$monster->cooldown();
		// Check skill countdown
		$cdSuperCrush = $monster->get_cooldowns()[1];
		if ( $cdSuperCrush != 2 ) return array(false,"Le sort super crush devrait etre en cooldown pour 2 tours, pas ".$cdSuperCrush);
		
		// Check buff cooldown
		$cdBuff = $monster->get_buffs()[0]["turns"];
		if ( $cdBuff != 2 ) return array(false,"Le buff atk devrait etre en cooldown pour 2 tours, pas ".$cdBuff);
		// Check debuff cooldown
		$cdDebuff = $monster->get_debuffs()[0]["turns"];
		if ( $cdDebuff != 2 ) return array(false,"Le debuff atk devrait etre en cooldown pour 2 tours, pas ".$cdDebuff);
		
		// Launch mega smash
		$monster->choose_skill(0);
		// Check skill countdown
		$cdMegaSmash = $monster->get_cooldowns()[0];
		if ( $cdMegaSmash != 1 ) return array(false,"Le sort mega smash devrait etre en cooldown pour 1 tour, pas ".$cdMegaSmash);
		
		// Cooldown
		$monster->cooldown();
		// Check skill countdown
		$cdMegaSmash = $monster->get_cooldowns()[0];
		$cdSuperCrush = $monster->get_cooldowns()[1];
		if ( $cdMegaSmash != 0 ) return array(false,"Le sort mega smash devrait etre en cooldown pour 0 tour, pas ".$cdMegaSmash);
		if ( $cdSuperCrush != 1 ) return array(false,"Le sort super crush devrait etre en cooldown pour 1 tours, pas ".$cdSuperCrush);
		
		// Check buff cooldown
		$cdBuff = $monster->get_buffs()[0]["turns"];
		if ( $cdBuff != 1 ) return array(false,"Le buff atk devrait etre en cooldown pour 1 tours, pas ".$cdBuff);
		// Check debuff cooldown
		$cdDebuff = $monster->get_debuffs()[0]["turns"];
		if ( $cdDebuff != 1 ) return array(false,"Le debuff atk devrait etre en cooldown pour 1 tours, pas ".$cdDebuff);
		
		return array(true,"OK");
	}
	
	//Créé Veromos avec buff atk, def, spd et cr et vérifie le bonus sur les stats en combat, puis lance 4 strip et vérifie le retour aux stats de départ
	function tf_monstre_stats_buff_strip(){
		$runeCode = "110110110000000100000100101110111100101100101110111100101000001010011000001000001010011000001100101110111100101000001010011000001";
		$monster = MonsterLib::load_monster("Veromos",$runeCode);
		
		$buffAtk = array("perCent"=>50,"type"=>BUFF::RAISEATK,"turns"=>2);
		$buffSpd = array("perCent"=>25,"type"=>BUFF::RAISESPD,"turns"=>3);
		$buffDef = array("perCent"=>75,"type"=>BUFF::RAISEDEF,"turns"=>1);
		$buffCr = array("perCent"=>75,"type"=>BUFF::RAISECR,"turns"=>1);
		$monster->add_buff($buffAtk);
		$monster->add_buff($buffDef);
		$monster->add_buff($buffSpd);
		$monster->add_buff($buffCr);
		
		
		// Calculate expected modifiers
		$monStats = $monster->get_runes_stats();
		$expectedAtkMod = round ( $monStats[STATS::ATK] * 0.5 );
		$expectedDefMod = round ( $monStats[STATS::DEF] * 0.7 );
		$expectedSpdMod = round ( $monStats[STATS::SPD] * 0.3 );
		$expectedCRMod = 30;
		
		// Check buff modifiers
		$bm = $monster->get_buff_mod();
		if ( $bm[STATS::ATK] != $expectedAtkMod ) return array(false,"Erreur buff modificateur ATK : ".$bm[STATS::ATK]." au lieu de ".$expectedAtkMod);
		if ( $bm[STATS::DEF] != $expectedDefMod ) return array(false,"Erreur buff modificateur DEF : ".$bm[STATS::DEF]." au lieu de ".$expectedDefMod);
		if ( $bm[STATS::SPD] != $expectedSpdMod ) return array(false,"Erreur buff modificateur SPD : ".$bm[STATS::SPD]." au lieu de ".$expectedSpdMod);
		if ( $bm[STATS::CR] != $expectedCRMod ) return array(false,"Erreur buff modificateur CR : ".$bm[STATS::CR]." au lieu de ".$expectedCRMod);
		
		
		// Calculate expected fightStats
		$expectedAtk = $monStats[STATS::ATK] + $expectedAtkMod;
		$expectedDef = $monStats[STATS::DEF] + $expectedDefMod;
		$expectedSpd = $monStats[STATS::SPD] + $expectedSpdMod;
		$expectedCR = $monStats[STATS::CR] + $expectedCRMod;
		
		// Check fightStats
		$fs = $monster->get_fight_stats();
		if ( $fs[STATS::ATK] != $expectedAtk ) return array(false,"Erreur buff stat ATK : ".$fs[STATS::ATK]." au lieu de ".$expectedAtk);
		if ( $fs[STATS::DEF] != $expectedDef ) return array(false,"Erreur buff stat DEF : ".$fs[STATS::DEF]." au lieu de ".$expectedDef);
		if ( $fs[STATS::SPD] != $expectedSpd ) return array(false,"Erreur buff stat SPD : ".$fs[STATS::SPD]." au lieu de ".$expectedSpd);
		if ( $fs[STATS::CR] != $expectedCR ) return array(false,"Erreur buff stat CR : ".$fs[STATS::CR]." au lieu de ".$expectedCR);
		
		
		// Strip ATK
		$monster->remove_buff();
		$bm = $monster->get_buff_mod()[STATS::ATK];
		$fs = $monster->get_fight_stats()[STATS::ATK];
		if ( $bm != 0 ) return array(false,"Erreur strip modificateur ATK : ".$bm." au lieu de 0");
		if ( $fs != $monStats[STATS::ATK] ) return array(false,"Erreur strip stat ATK : ".$fs." au lieu de ".$monStats[STATS::ATK]);
		
		// Strip DEF
		$monster->remove_buff();
		$bm = $monster->get_buff_mod()[STATS::DEF];
		$fs = $monster->get_fight_stats()[STATS::DEF];
		if ( $bm != 0 ) return array(false,"Erreur strip modificateur DEF : ".$bm." au lieu de 0");
		if ( $fs != $monStats[STATS::DEF] ) return array(false,"Erreur strip stat DEF : ".$fs." au lieu de ".$monStats[STATS::DEF]);
		
		// Strip SPD
		$monster->remove_buff();
		$bm = $monster->get_buff_mod()[STATS::SPD];
		$fs = $monster->get_fight_stats()[STATS::SPD];
		if ( $bm != 0 ) return array(false,"Erreur strip modificateur SPD : ".$bm." au lieu de 0");
		if ( $fs != $monStats[STATS::SPD] ) return array(false,"Erreur strip stat SPD : ".$fs." au lieu de ".$monStats[STATS::SPD]);
		
		// Strip CR
		$monster->remove_buff();
		$bm = $monster->get_buff_mod()[STATS::CR];
		$fs = $monster->get_fight_stats()[STATS::CR];
		if ( $bm != 0 ) return array(false,"Erreur strip modificateur CR : ".$bm." au lieu de 0");
		if ( $fs != $monStats[STATS::CR] ) return array(false,"Erreur strip stat CR : ".$fs." au lieu de ".$monStats[STATS::CR]);
		
		return array(true,"OK");
	}
	
	//Créé un monstre avec debuff atk, def et spd et vérifie le malus sur les stats en combat, puis lance 4 cleanse et vérifie le retour aux stats de départ
	function tf_monstre_stats_debuff_cleanse(){
		$runeCode = "110110110000000100000100101110111100101100101110111100101000001010011000001000001010011000001100101110111100101000001010011000001";
		$monster = MonsterLib::load_monster("Veromos",$runeCode);
		
		$debuffAtk = array("perCent"=>50,"type"=>DEBUFF::LOWATK,"turns"=>2);
		$debuffDef = array("perCent"=>25,"type"=>DEBUFF::LOWDEF,"turns"=>3);
		$debuffSpd = array("perCent"=>75,"type"=>DEBUFF::LOWSPD,"turns"=>1);
		$monster->add_debuff($debuffAtk);
		$monster->add_debuff($debuffDef);
		$monster->add_debuff($debuffSpd);
		
		
		// Calculate expected modifiers
		$monStats = $monster->get_runes_stats();
		$expectedAtkMod = round ( $monStats[STATS::ATK] * -0.5 );
		$expectedDefMod = round ( $monStats[STATS::DEF] * -0.7 );
		$expectedSpdMod = round ( $monStats[STATS::SPD] * -0.3 );
		
		// Check buff modifiers
		$bm = $monster->get_buff_mod();
		if ( $bm[STATS::ATK] != $expectedAtkMod ) return array(false,"Erreur debuff modificateur ATK : ".$bm[STATS::ATK]." au lieu de ".$expectedAtkMod);
		if ( $bm[STATS::DEF] != $expectedDefMod ) return array(false,"Erreur debuff modificateur DEF : ".$bm[STATS::DEF]." au lieu de ".$expectedDefMod);
		if ( $bm[STATS::SPD] != $expectedSpdMod ) return array(false,"Erreur debuff modificateur SPD : ".$bm[STATS::SPD]." au lieu de ".$expectedSpdMod);
		
		
		// Calculate expected fightStats
		$expectedAtk = $monStats[STATS::ATK] + $expectedAtkMod;
		$expectedDef = $monStats[STATS::DEF] + $expectedDefMod;
		$expectedSpd = $monStats[STATS::SPD] + $expectedSpdMod;
		
		// Check fightStats
		$fs = $monster->get_fight_stats();
		if ( $fs[STATS::ATK] != $expectedAtk ) return array(false,"Erreur debuff stat ATK : ".$fs[STATS::ATK]." au lieu de ".$expectedAtk);
		if ( $fs[STATS::DEF] != $expectedDef ) return array(false,"Erreur debuff stat DEF : ".$fs[STATS::DEF]." au lieu de ".$expectedDef);
		if ( $fs[STATS::SPD] != $expectedSpd ) return array(false,"Erreur debuff stat SPD : ".$fs[STATS::SPD]." au lieu de ".$expectedSpd);
		
		
		// Cleanse ATK
		$monster->remove_debuff();
		$bm = $monster->get_buff_mod()[STATS::ATK];
		$fs = $monster->get_fight_stats()[STATS::ATK];
		if ( $bm != 0 ) return array(false,"Erreur modificateur ATK : ".$bm." au lieu de 0");
		if ( $fs != $monStats[STATS::ATK] ) return array(false,"Erreur stat ATK : ".$fs." au lieu de ".$monStats[STATS::ATK]);
		// Cleanse DEF
		$monster->remove_debuff();
		$bm = $monster->get_buff_mod()[STATS::DEF];
		$fs = $monster->get_fight_stats()[STATS::DEF];
		if ( $bm != 0 ) return array(false,"Erreur modificateur DEF : ".$bm." au lieu de 0");
		if ( $fs != $monStats[STATS::DEF] ) return array(false,"Erreur stat DEF : ".$fs." au lieu de ".$monStats[STATS::DEF]);
		// Cleanse SPD
		$monster->remove_debuff();
		$bm = $monster->get_buff_mod()[STATS::SPD];
		$fs = $monster->get_fight_stats()[STATS::SPD];
		if ( $bm != 0 ) return array(false,"Erreur modificateur SPD : ".$bm." au lieu de 0");
		if ( $fs != $monStats[STATS::SPD] ) return array(false,"Erreur stat SPD : ".$fs." au lieu de ".$monStats[STATS::SPD]);
		
		return array(true,"OK");
	}
	
	//Vérifie les stats en combat pour les buff/debuff sur la meme stat : buff atk, debuff atk, strip buff, cleanse debuff 
	function tf_monstre_stats_buff_debuff(){
		$runeCode = "110110110000000100000100101110111100101100101110111100101000001010011000001000001010011000001100101110111100101000001010011000001";
		$monster = MonsterLib::load_monster("Veromos",$runeCode);
		
		$debuffAtk = array("perCent"=>50,"type"=>DEBUFF::LOWATK,"turns"=>2);
		$buffAtk = array("perCent"=>50,"type"=>BUFF::RAISEATK,"turns"=>2);
		
		// Calculate expected results
		$monStats = $monster->get_runes_stats();
		$modStat = round($monStats[STATS::ATK]*0.5);
		$regularStat = $monStats[STATS::ATK];
		$buffedStat = round($monStats[STATS::ATK]*1.5);
		$debuffedStat = $modStat;
		
		$monster->add_buff($buffAtk);
		$bm = $monster->get_buff_mod();
		$fs = $monster->get_fight_stats()[STATS::ATK];
		if ( $bm[STATS::ATK] != $modStat ) return array(false,"Erreur modificateur ATK after buff : ".$bm[STATS::ATK]." au lieu de ".$modStat);
		if ( $fs != $buffedStat ) return array(false,"Erreur stat ATK after buff : ".$fs." au lieu de ".$buffedStat);
		
		$monster->add_debuff($debuffAtk);
		$bm = $monster->get_buff_mod();
		$fs = $monster->get_fight_stats()[STATS::ATK];
		if ( $bm[STATS::ATK] != 0 ) return array(false,"Erreur modificateur ATK after debuff : ".$bm[STATS::ATK]." au lieu de 0");
		if ( $fs != $regularStat ) return array(false,"Erreur stat ATK after debuff : ".$fs." au lieu de ".$regularStat);
		
		$monster->remove_buff();
		$bm = $monster->get_buff_mod()[STATS::ATK];
		$fs = $monster->get_fight_stats()[STATS::ATK];
		if ( $bm != -1*$modStat ) return array(false,"Erreur modificateur ATK after strip : ".$bm." au lieu de -".$modStat);
		if ( $fs != $debuffedStat ) return array(false,"Erreur stat ATK after strip : ".$fs." au lieu de ".$debuffedStat);
		
		$monster->remove_debuff();
		$bm = $monster->get_buff_mod()[STATS::ATK];
		$fs = $monster->get_fight_stats()[STATS::ATK];
		if ( $bm != 0 ) return array(false,"Erreur modificateur ATK after cleanse : ".$bm." au lieu de 0");
		if ( $fs != $regularStat ) return array(false,"Erreur stat ATK after cleanse : ".$fs." au lieu de ".$regularStat);
		
		return array(true,"OK");
	}
	
	//Créé un monstre, lui inflige des dégats et vérifie la perte de pv puis ajoute un buff heal et vérifie le gain de pv dans les stats de combat
	function tf_monstre_takeHit_heal(){
		$runeCode = "110110110000000100000100101110111100101110111000001010011000001010011100101110111000001010011";
		$monster = MonsterLib::load_monster("Veromos",$runeCode);
		
		// Take hit
		$dmg = 3000;
		$pvAvant = $monster->get_fight_stat(STATS::HP);
		$monster->take_hit($dmg);
		$pvApres = $monster->get_fight_stat(STATS::HP);
		if ( $pvApres != $pvAvant - $dmg ) return array(false,"take_hit : Les PV devraient etre $pvAvant - $dmg = ".($pvAvant-$dmg).", pas $pvApres");
		
		// Heal
		$buffHeal = array("perCent"=>50,"type"=>BUFF::HEAL,"turns"=>2);
		$monster->add_buff($buffHeal);
		$pvMax = $monster->get_fight_stat(STATS::MAXHP);
		$pvAvant = $monster->get_fight_stat(STATS::HP);
		$healEffect = round($pvMax * 0.15);
		$monster->apply_heal_buff();
		$pvApres = $monster->get_fight_stat(STATS::HP);
		if ( $pvApres != $pvAvant + $healEffect ) return array(false,"heal 1 : Les PV devraient etre $pvAvant + $healEffect = ".($pvAvant+$healEffect).", pas $pvApres");
		// Re-heal
		$monster->apply_heal_buff();
		$pvApres = $monster->get_fight_stat(STATS::HP);
		if ( $pvApres > $pvMax ) return array(false,"heal 2 : Les PV devraient plafonner à ".($pvMax).", pas $pvApres");
		
		// TODO : appliquer DEBUFF::NOHEAL et verifier l'absence de soin
		
		return array(true,"OK");
	}
	
	//Créé un monstre avec 3 debuff constDmg et vérifie leur cumul et la perte de hp dans les stats de combat
	function tf_monstre_constant_dmg(){
		$runeCode = "110110110000000100000100101110111100101110111000001010011000001010011100101110111000001010011";
		$monster = MonsterLib::load_monster("Veromos",$runeCode);
		
		$debuffDmg = array("perCent"=>50,"type"=>DEBUFF::CONSTDMG,"turns"=>2);
		$monster->add_debuff($debuffDmg);
		
		$pvAvant = $monster->get_fight_stat(STATS::HP);
		$dmg = round($monster->get_fight_stat(STATS::MAXHP) * 0.05);
		$monster->apply_constant_damages();
		$pvApres = $monster->get_fight_stat(STATS::HP);
		if ( $pvApres != $pvAvant - $dmg ) return array(false,"Les PV devraient etre $pvAvant - $dmg = ".($pvAvant-$dmg).", pas $pvApres");
		
		// verifier cumul des degats constants
		$monster->add_debuff($debuffDmg);
		$monster->add_debuff($debuffDmg);
		$pvAvant = $pvApres;
		$monster->apply_constant_damages();
		$pvApres = $monster->get_fight_stat(STATS::HP);
		if ( $pvApres != $pvAvant-(3*$dmg) ) return array(false,"Les PV devraient etre $pvAvant - (3*$dmg) = ".($pvAvant-($dmg*3)).", pas $pvApres");
		
		return array(true,"OK");
	}
	
	
	
	
	
	
	//////////////////////////////////////////////
	////////////	COMBAT		//////////////////
	//////////////////////////////////////////////
	
	
	//Teste les avantages elementaires
	function tu_combat_avantage_element(){
		
		if ( $v = Combat::has_advantage(ELMT::water,ELMT::water) != 0 ) return array(false,"Eau vs Eau doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::water,ELMT::fire) != 1 ) return array(false,"Eau vs Feu doit donner 1, pas $v");
		if ( $v = Combat::has_advantage(ELMT::water,ELMT::wind) != -1 ) return array(false,"Eau vs Vent doit donner -1, pas $v");
		if ( $v = Combat::has_advantage(ELMT::water,ELMT::dark) != 0 ) return array(false,"Eau vs Ombre doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::water,ELMT::light) != 0 ) return array(false,"Eau vs Lumiere doit donner 0, pas $v");
		
		if ( $v = Combat::has_advantage(ELMT::fire,ELMT::water) != -1 ) return array(false,"Feu vs Eau doit donner -1, pas $v");
		if ( $v = Combat::has_advantage(ELMT::fire,ELMT::fire) != 0 ) return array(false,"Feu vs Feu doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::fire,ELMT::wind) != 1 ) return array(false,"Feu vs Vent doit donner 1, pas $v");
		if ( $v = Combat::has_advantage(ELMT::fire,ELMT::dark) != 0 ) return array(false,"Feu vs Ombre doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::fire,ELMT::light) != 0 ) return array(false,"Feu vs Lumiere doit donner 0, pas $v");
		
		if ( $v = Combat::has_advantage(ELMT::wind,ELMT::water) != 1 ) return array(false,"Vent vs Eau doit donner 1, pas $v");
		if ( $v = Combat::has_advantage(ELMT::wind,ELMT::fire) != -1 ) return array(false,"Vent vs Feu doit donner -1, pas $v");
		if ( $v = Combat::has_advantage(ELMT::wind,ELMT::wind) != 0 ) return array(false,"Vent vs Vent doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::wind,ELMT::dark) != 0 ) return array(false,"Vent vs Ombre doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::wind,ELMT::light) != 0 ) return array(false,"Vent vs Lumiere doit donner 0, pas $v");
		
		if ( $v = Combat::has_advantage(ELMT::dark,ELMT::water) != 0 ) return array(false,"Ombre vs Eau doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::dark,ELMT::fire) != 0 ) return array(false,"Ombre vs Feu doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::dark,ELMT::wind) != 0 ) return array(false,"Ombre vs Vent doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::dark,ELMT::dark) != 0 ) return array(false,"Ombre vs Ombre doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::dark,ELMT::light) != 1 ) return array(false,"Ombre vs Lumiere doit donner 1, pas $v");
		
		if ( $v = Combat::has_advantage(ELMT::light,ELMT::water) != 0 ) return array(false,"Lumiere vs Eau doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::light,ELMT::fire) != 0 ) return array(false,"Lumiere vs Feu doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::light,ELMT::wind) != 0 ) return array(false,"Lumiere vs Vent doit donner 0, pas $v");
		if ( $v = Combat::has_advantage(ELMT::light,ELMT::dark) != 1 ) return array(false,"Lumiere vs Ombre doit donner 1, pas $v");
		if ( $v = Combat::has_advantage(ELMT::light,ELMT::light) != 0 ) return array(false,"Lumiere vs Lumiere doit donner 0, pas $v");
		
		return array(true,"OK");
	}
	
	//Lance un combat
	function tm_combat(){
		return array(false,"Pas implémenté");
	}
	
	// ATK vs DEF
	// PRE vs RES
	
	
	/*
	HP+		00000000
	HP+%	00010000
	Atq+	00100000
	Atq+%	00110000
	Def+	01000000
	Def+%	01010000
	Vit+	01100000
	Vit+%	interdit
	CR+		interdit
	CR+%	10010000
	CD+		interdit
	CD+%	10110000
	Pre+	interdit
	Pre+%	11010000
	Res+	interdit
	Res+%	11110000
	*/
?>
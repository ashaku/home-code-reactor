
<?
	include('AlgoGen.php');
?>


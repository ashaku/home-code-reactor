<?
	// LIBRAIRIE DES TESTS

	//Créé une rune 2 Energy / SPD+42 / CR+5% CD+5% PRE+5% RES+5% et vérifie que le code fourni est bien décodé
	function tu_rune_decode(){
		// Créé code
		// Energy Main:SPD+42 Sub: CR+5% CD+5% PRE+5% RES+5%
		$code = "000010010000101100001101000011110000";
		
		// Créer rune
		$r = new Rune($code,2,STATS::SPD);
		
		// Verifier famille
		$f = RUNEFAMILY::get_name($r->get_family());
		if ( $f != "Energy" )	return array(false,"Erreur decode : famille incorrecte ('$f' au lieu de 'Energy')");
		
		// Verifier main
		$m = $r->get_mainStat();
		$ms = STATS::get_short_name($m->get_stat());
		if ( $ms != "SPD" )	return array(false,"Erreur decode : mainStat incorrecte ('$ms' au lieu de 'SPD')");
		$mt = $m->get_type();
		if ( $mt != "0" )	return array(false,"Erreur decode : mainType incorrect ('$mt' au lieu de '0')");
		$mv = $m->get_value();
		if ( $mv != 42 )	return array(false,"Erreur decode : mainValue incorrect ('$mv' au lieu de '42')");
		
		// Verifier sub
		$s = $r->get_subStats();
		$i = 4;
		foreach ( $s as $sub ){
			$ms = $sub->get_stat();
			if ( $ms != $i )	return array(false,"Erreur decode : mainStat ".($i-3)." incorrecte ('$ms' au lieu de '$i')");
			$mt = $sub->get_type();
			if ( $mt != "1" )	return array(false,"Erreur decode : mainType ".($i-3)." incorrect ('$mt' au lieu de '1')");
			$mv = $sub->get_value();
			if ( $mv != 5 )	return array(false,"Erreur decode : mainValue ".($i-3)." incorrect ('$mv' au lieu de '5')");
			$i++;
		}
		
		// Vérifier code binaire
		$c = $r->get_code();
		if ( $c != $code )	return array(false,"Erreur decode : code binaire modifié ('$c' au lieu de '$code')");
		
		return array(true,"OK");
	}
	
	//Créé une rune avec une erreur et vérifie la correction
	function tu_rune_correct(){
		// Créer une rune avec un sub en double
		// Energy Main:PV+63% Sub:PV+125 PV+125 Def+125 Def+5%
		$code = "000000000000000000000100000001010000";
		$r = new Rune($code,1,STATS::HP);
		
		// Verifie que la stat en erreur a changé
		$s = $r->get_subStats();
		if ( $s[1]->get_stat() == STATS::HP )	return array(false,"Erreur de correction de sub : stat inchangée");
		
		// Verifie que la stat fournie en double n est pas comptée en double
		$mods = $r->get_statsModifiers();
		if ( $mods[0] != 125 )	return array(false,"Erreur de correction de sub : stat comptée en double");
		
		// Verifie que le code binaire de la rune a changé
		$newRuneCode = $r->get_code();
		if ( $newRuneCode == $code )	return array(false,"Erreur de correction de sub : code binaire inchangé");
		
		return array(true,"OK");
	}
	
	//Créé une rune Energy / Atq+63% / HP+125 HP+5% Atq+125 Def+125 et vérifie les modificateurs (somme de tous les bonus) 
	function tu_rune_modifiers(){
		////Energy Main:Atq+63% Sub:HP+125 HP+5% Atq+125 Def+125
		$code = "000000000000000100000010000001000000";
		$r = new Rune($code,2,STATS::ATK);
		$mods = $r->get_statsModifiers();
		if ( $mods[0] != 125 )	return array(false,"Erreur de calcul des modificateurs : hp+ incorrect ('".$mod[0]."' au lieu de '125')");
		if ( $mods[1] != 5 )	return array(false,"Erreur de calcul des modificateurs : hp+% incorrect ('".$mod[1]."' au lieu de '5')");
		if ( $mods[2] != 125 )	return array(false,"Erreur de calcul des modificateurs : atq+ incorrect ('".$mod[2]."' au lieu de '125')");
		if ( $mods[3] != 63 )	return array(false,"Erreur de calcul des modificateurs : atq+% incorrect ('".$mod[3]."' au lieu de '63')");
		if ( $mods[4] != 125 )	return array(false,"Erreur de calcul des modificateurs : def+ incorrect ('".$mod[4]."' au lieu de '125')");
		for ( $i=5; $i<16; $i++ ){
			if ( $mods[$i] != 0 )	return array(false,"Erreur de calcul des modificateurs : stat $i incorrect ('".$mod[$i]."' au lieu de '0')");
		}
		
		///////////////////////////////////////////////////////
		// TODO : 2 autres runes qui testent 10 autres stats //
		///////////////////////////////////////////////////////
		
		return array(true,"OK");
	}
	
	//Teste les avantages elementaires
	function tu_combat_avantages_elementaires(){
		
	}
	
	
	
	//Créé 6 runes à partir d un set prédéfini et vérifie les modificateurs (famille + bonus)
	function tf_runage(){
		// Créer code
		$mains = "11100110";	// SPD CR PRE
		$rune1 = "000000000000000100000011000001000000";	// Energy / Atq+ / HP+ HP+% Atq+% Def+
		$rune2 = "000001010000100100001011000011010000";	// Energy / Vit+ / Def+% CR+% CD+% Pre+%
		$rune3 = "110011110000000000000001000000100000";	// Fatal / Def+ / Res+% HP+ HP+% Atq+
		$rune4 = "110000110000010000000101000001100000";	// Fatal / CR+% / Atq+% Def+ Def+% Vit+
		$rune5 = "110010010000101100001101000011110000";	// Fatal / HP+ / CR+% CD+% Pre+% Res+%
		$rune6 = "110000010000001000000011000001010000";	// Fatal / Pre+% / HP+% Atq+ Atq+% Def+%
		$runageCode = $mains.$rune1.$rune2.$rune3.$rune4.$rune5.$rune6;
		
		// Créer runage
		$runage = new Runage($runageCode);
		
		// Verifier modifiers
		$statMod = $runage->get_stats_modifiers();
		if ( $statMod[0] != 2698 )	return array(false,"Erreur stat HP+ : ".$statMod[0]." au lieu de 2698");
		if ( $statMod[1] != 15 )	return array(false,"Erreur stat HP+% : ".$statMod[1]." au lieu de 15");
		if ( $statMod[2] != 410 )	return array(false,"Erreur stat ATK+ : ".$statMod[2]." au lieu de 410");
		if ( $statMod[3] != 15 )	return array(false,"Erreur stat ATK+% : ".$statMod[3]." au lieu de 15");
		if ( $statMod[4] != 410 )	return array(false,"Erreur stat DEF+ : ".$statMod[4]." au lieu de 410");
		if ( $statMod[5] != 15 )	return array(false,"Erreur stat DEF+% : ".$statMod[5]." au lieu de 15");
		if ( $statMod[6] != 47 )	return array(false,"Erreur stat SPD+ : ".$statMod[6]." au lieu de 47");
		if ( $statMod[7] != 0 )		return array(false,"Erreur stat SP+% : ".$statMod[7]." au lieu de 0");
		if ( $statMod[8] != 0 )		return array(false,"Erreur stat CR+ : ".$statMod[8]." au lieu de 0");
		if ( $statMod[9] != 75 )	return array(false,"Erreur stat CR+% : ".$statMod[9]." au lieu de 75");
		if ( $statMod[10] != 0 )	return array(false,"Erreur stat CD+ : ".$statMod[10]." au lieu de 0");
		if ( $statMod[11] != 10 )	return array(false,"Erreur stat CD+% : ".$statMod[11]." au lieu de 10");
		if ( $statMod[12] != 0 )	return array(false,"Erreur stat PRE+ : ".$statMod[12]." au lieu de 0");
		if ( $statMod[13] != 90 )	return array(false,"Erreur stat PRE+% : ".$statMod[13]." au lieu de 90");
		if ( $statMod[14] != 0 )	return array(false,"Erreur stat RES+ : ".$statMod[14]." au lieu de 0");
		if ( $statMod[15] != 10 )	return array(false,"Erreur stat RES+% : ".$statMod[15]." au lieu de 10");
		
		$statMod = $runage->get_family_modifiers();
		if ( $statMod[0] != 0 )	return array(false,"Erreur famille HP+ : ".$statMod[0]." au lieu de 0");
		if ( $statMod[1] != 15 )	return array(false,"Erreur famille HP+% : ".$statMod[1]." au lieu de 15");
		if ( $statMod[2] != 0 )	return array(false,"Erreur famille ATK+ : ".$statMod[2]." au lieu de 0");
		if ( $statMod[3] != 35 )	return array(false,"Erreur famille ATK+% : ".$statMod[3]." au lieu de 35");
		if ( $statMod[4] != 0 )	return array(false,"Erreur famille DEF+ : ".$statMod[4]." au lieu de 0");
		if ( $statMod[5] != 0 )	return array(false,"Erreur famille DEF+% : ".$statMod[5]." au lieu de 0");
		if ( $statMod[6] != 0 )	return array(false,"Erreur famille SPD+ : ".$statMod[6]." au lieu de 0");
		if ( $statMod[7] != 0 )		return array(false,"Erreur famille SP+% : ".$statMod[7]." au lieu de 0");
		if ( $statMod[8] != 0 )		return array(false,"Erreur famille CR+ : ".$statMod[8]." au lieu de 0");
		if ( $statMod[9] != 0 )	return array(false,"Erreur famille CR+% : ".$statMod[9]." au lieu de 0");
		if ( $statMod[10] != 0 )	return array(false,"Erreur famille CD+ : ".$statMod[10]." au lieu de 0");
		if ( $statMod[11] != 0 )	return array(false,"Erreur famille CD+% : ".$statMod[11]." au lieu de 0");
		if ( $statMod[12] != 0 )	return array(false,"Erreur famille PRE+ : ".$statMod[12]." au lieu de 0");
		if ( $statMod[13] != 0 )	return array(false,"Erreur famille PRE+% : ".$statMod[13]." au lieu de 0");
		if ( $statMod[14] != 0 )	return array(false,"Erreur famille RES+ : ".$statMod[14]." au lieu de 0");
		if ( $statMod[15] != 0 )	return array(false,"Erreur famille RES+% : ".$statMod[15]." au lieu de 0");
		return array(true,"OK");
	}
	
	//Créé un monstre avec son runage et vérifie ses stats finales
	function tf_monstre(){
		
		$name = "Veromos";
		$element = ELMT::dark;
		$stats = array(9225,769,758,100,15,50,0,15);
		$mains = "11100110";	// SPD CR PRE
		$rune1 = "000000000000000100000011000001000000";	// Energy / Atq+ / HP+ HP+% Atq+% Def+
		$rune2 = "000001010000100100001011000011010000";	// Energy / Vit+ / Def+% CR+% CD+% Pre+%
		$rune3 = "110011110000000000000001000000100000";	// Fatal / Def+ / Res+% HP+ HP+% Atq+
		$rune4 = "110000110000010000000101000001100000";	// Fatal / CR+% / Atq+% Def+ Def+% Vit+
		$rune5 = "110010010000101100001101000011110000";	// Fatal / HP+ / CR+% CD+% Pre+% Res+%
		$rune6 = "110000010000001000000011000001010000";	// Fatal / Pre+% / HP+% Atq+ Atq+% Def+%
		$runeCode = $mains.$rune1.$rune2.$rune3.$rune4.$rune5.$rune6;
		$m = new Monster($name,$element,$stats,$runeCode);
		$statMod = $m->get_statsMod();
		if ( $statMod[0] != 5466 )	return array(false,"Erreur stat HP : +".$statMod[0]." au lieu de +5466");
		if ( $statMod[1] != 794 )	return array(false,"Erreur stat ATK : ".$statMod[1]." au lieu de +794");
		if ( $statMod[2] != 524 )	return array(false,"Erreur stat DEF : ".$statMod[2]." au lieu de +524");
		if ( $statMod[3] != 47 )	return array(false,"Erreur stat SPD : ".$statMod[3]." au lieu de +47");
		if ( $statMod[4] != 75 )	return array(false,"Erreur stat CR : ".$statMod[4]." au lieu de +75");
		if ( $statMod[5] != 10 )	return array(false,"Erreur stat CD : ".$statMod[5]." au lieu de 10");
		if ( $statMod[6] != 90 )	return array(false,"Erreur stat PRE : ".$statMod[6]." au lieu de 90");
		if ( $statMod[7] != 10 )	return array(false,"Erreur stat RES : ".$statMod[7]." au lieu de 10");
		
		return array(true,"OK");
	}
	
	
	
	/*
	HP+		00000000
	HP+%	00010000
	Atq+	00100000
	Atq+%	00110000
	Def+	01000000
	Def+%	01010000
	Vit+	01100000
	Vit+%	interdit
	CR+		interdit
	CR+%	10010000
	CD+		interdit
	CD+%	10110000
	Pre+	interdit
	Pre+%	11010000
	Res+	interdit
	Res+%	11110000
	*/
?>
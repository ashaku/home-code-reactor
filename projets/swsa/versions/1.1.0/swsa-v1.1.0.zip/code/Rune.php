<?
	// Represent a rune collection
	// Must be initialized by a binary combination
	
	// Set of 6 runes held by a monster
	class Runage{
		
		private $rawCode;	// binary code of runage
		private $runes;		// list of rune objects
		private $statsModifiers;
		private $families;
		private $familyModifiers;
		
		function __construct($aCode){
			$this->rawCode = $aCode;
			$this->decode();
			$this->statsModifiers = array();
			$this->familyModifiers = array();
			$this->calculate_stats_modifiers();
		}
	
		public function get_stats_modifiers(){	return $this->statsModifiers;	}
		public function get_family_modifiers(){	return $this->familyModifiers;	}
		public function get_families(){			return $this->families;			}
		public function get_main_stats(){
			return array($this->runes[1]->get_mainStat()->get_stat(),$this->runes[3]->get_mainStat()->get_stat(),$this->runes[5]->get_mainStat()->get_stat());
		}
		
		// Read code and save as rune stats
		// May update code itself if runes are auto-corrected
		private function decode (){
			
			// For each of 6 runes
			$update_code = false;
			for ($i=0; $i<6; $i++ ){
				
				// Create & save rune
				$runeCode = substr($this->rawCode,8+$i*36,36);
				switch ($i){
					case 1 : $mainCode = bindec(substr($this->rawCode,0,2)); break;
					case 3 : $mainCode = bindec(substr($this->rawCode,2,3)); break;
					case 5 : $mainCode = bindec(substr($this->rawCode,5,3)); break;
					default: $mainCode = -1;
				}
				$rune = new Rune($runeCode,$i+1,$mainCode);
				$this->runes[$i] = $rune;
				if ( $rune->has_errors() ) $update_code = true;
			}
			if ( $update_code ){
				$oldCode = $this->rawCode;
				$newCode = substr($oldCode,0,8);
				foreach ( $this->runes as $rune ){
					$newCode .= $rune->get_code();
				}
				$this->rawCode = $newCode;
			}
		}
		
		// Will agregate statsModifiers from all 6 rune and check rune families to grant family bonus
		private function calculate_stats_modifiers(){
			
			$families = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
			$this->statsModifiers = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
			$this->families = array();
			$this->familyModifiers = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
			foreach ( $this->runes as $rune ){
				// save family
				$families[$rune->get_family()]++;
				
				// Agregate rune modifiers
				$mod = $rune->get_statsModifiers();
				for ( $i=0; $i<16; $i++ ){
					$this->statsModifiers[$i] += $mod[$i];
				}
			}
			
			// Check for family bonus
			foreach($families as $f => $n){
				if ( $f<10 && $n>1 ){
					switch ($f){
						case RUNEFAMILY::Energy :
							$this->familyModifiers[1] += floor($n/2) * 15;
							for ( $i=0; $i<floor($n/2); $i++ ){
								array_push($this->families,"Energy");
							}
							break;
						case RUNEFAMILY::Guard :
							$this->familyModifiers[5] += floor($n/2) * 15;
							for ( $i=0; $i<floor($n/2); $i++ ){
								array_push($this->families,"Guard");
							}
							break;
						case RUNEFAMILY::Blade :
							$this->familyModifiers[9] += floor($n/2) * 12;
							for ( $i=0; $i<floor($n/2); $i++ ){
								array_push($this->families,"Blade");
							}
							break;
						case RUNEFAMILY::Focus :
							$this->familyModifiers[13] += floor($n/2) * 20;
							for ( $i=0; $i<floor($n/2); $i++ ){
								array_push($this->families,"Focus");
							}
							break;
						case RUNEFAMILY::Endure :
							$this->familyModifiers[15] += floor($n/2) * 20;
							for ( $i=0; $i<floor($n/2); $i++ ){
								array_push($this->families,"Endure");
							}
							break;
						case RUNEFAMILY::Nemesis : //jauge atk+4% chaque 7%PV perdus
							//$this->familyModifiers[1] += floor($n/2) * 15;
							break;
						case RUNEFAMILY::Will :	// immune 1 turn
							//$this->familyModifiers[1] += floor($n/2) * 15;
							break;
						case RUNEFAMILY::Shield :	// Shield 15%HP 3 turns
							//$this->familyModifiers[1] += floor($n/2) * 15;
							break;
						case RUNEFAMILY::Revenge :	// counter 15%
							//$this->familyModifiers[1] += floor($n/2) * 15;
							break;
						case RUNEFAMILY::Destroy :	// pv max ennemy -4% tous les 30% degats
							//$this->familyModifiers[1] += floor($n/2) * 15;
							break;
					}
				}
				if ( $f>=10 && $n>3 ){
					switch ($f){
						case RUNEFAMILY::Swift :
							$this->familyModifiers[7] += 25;
							array_push($this->families,"Swift");
							break;
						case RUNEFAMILY::Rage :
							$this->familyModifiers[11] += 40;
							array_push($this->families,"Rage");
							break;
						case RUNEFAMILY::Fatal :
							$this->familyModifiers[3] += 35;
							array_push($this->families,"Fatal");
							break;
						case RUNEFAMILY::Despair :	// stun +25%
							//$this->familyModifiers[11] += 40;
							break;
						case RUNEFAMILY::Vampire :	// lifeleech 35%
							//$this->familyModifiers[11] += 40;
							break;
						case RUNEFAMILY::Violent :	// extra turn 22%
							//$this->familyModifiers[11] += 40;
							break;
					}
				}
			}
		}
		
		public function display(){
			
			echo "<div class='runage'>";
			$showBonus = false;
			if ( $showBonus ){
				echo "Family bonus : ";
				foreach ( $this->familyModifiers as $s => $v ){
					if ( $v > 0 ){
						echo "<span>".STATS::get_short_name(floor($s/2))."+".$v;
						if ( $s % 2 == 1 ) echo "%";
						echo "</span>";
					}
				}
				echo "<br><br>Sub bonus : ";
				foreach ( $this->statsModifiers as $s => $v ){
					if ( $v > 0 ){
						echo "<span>".STATS::get_short_name(floor($s/2))."+".$v;
						if ( $s % 2 == 1 ) echo "%";
						echo "</span>";
					}
				}
				echo "<br><br>";
			}
			echo "<table cellspacing=0 width=100%>
			<tr><td colspan=2>&nbsp;</td><td rowspan=3>";
			$this->runes[0]->display();
			echo "</td><td colspan=2>&nbsp;</td></tr>
			<tr><td rowspan=3>";
			$this->runes[5]->display();
			echo "</td><td>&nbsp;</td><td>&nbsp;</td><td rowspan=3>";
			$this->runes[1]->display();
			echo "</td></tr>
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
			<tr><td colspan=3>&nbsp;</td></tr>
			<tr><td colspan=5>&nbsp;</td></tr>";
			
			echo "<tr><td rowspan=3>";
			$this->runes[4]->display();
			echo "</td><td colspan=3>&nbsp;</td><td rowspan=3>";
			$this->runes[2]->display();
			echo "</td></tr>";
			
			echo "<tr><td>&nbsp;</td><td rowspan=3>";
			$this->runes[3]->display();
			echo "</td><td>&nbsp;</td></tr>
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
			<tr><td colspan=2>&nbsp;</td><td colspan=2>&nbsp;</td></tr>
			</table></div>";
		}
	}
	
	// Solo rune (set of bonuses)
	class Rune{
		private $code;
		private $position;	// 1 ~6
		private $family;	// RUNEFAMILY
		private $mainStat; 	// Bonus
		private $subStats;	// Bonus[]
		private $statsModifiers;
		
		private $tabRunesKeys;
		private $tabRunesErrors;
		
		
		// ============= RUNE CREATION ==============================
		function __construct($aCode,$aPosition,$aMain){
			$this->code = $aCode;
			$this->position = $aPosition;
			$this->subStats = array();
			$this->decode($aMain);
			$this->check_and_correct();
			$this->calculate_stats_modifiers();
		}
		
		// Read binary code and create according stats
		private function decode ($aMainStat){
			
			// Set family
			$family = bindec(substr($this->code,0,4));
			$this->set_family($family);
			
			// Define main stat
			switch($this->position){
				
				case 1 :	// RUNE 1 ATK
					$mainStat = STATS::ATK;
					$mainType = 0;
					$mainVal = 160;
					break;
					
				case 2 :	// RUNE 2
					$mainStat = $aMainStat;
					switch($aMainStat){
						case 0 : // HP
							$mainType = 1;
							$mainVal = 63;
							break;
						case 1 : // ATK
							$mainType = 1;
							$mainVal = 63;
							break;
						case 2 : // DEF
							$mainType = 1;
							$mainVal = 63;
							break;
						case 3 : // SPD
							$mainType = 0;
							$mainVal = 42;
							break;
					}
					break;
					
				case 3 :	// RUNE 3 DEF
					$mainStat = STATS::DEF;
					$mainType = 0;
					$mainVal = 160;
					break;
					
				case 4 :	// RUNE 4
					$mainType = 1;
					switch($aMainStat){
						case 0 : // HP
						case 1 : // HP
							$mainStat = STATS::HP;
							$mainVal = 63;
							break;
						case 2 : // ATK
							$mainStat = STATS::ATK;
							$mainVal = 63;
							break;
						case 3 : // DEF
							$mainStat = STATS::DEF;
							$mainVal = 63;
							break;
						case 4 :
						case 5 : // CR
							$mainStat = STATS::CR;
							$mainVal = 65;
							break;
						case 6 :
						case 7 : // CD
							$mainStat = STATS::CD;
							$mainVal = 80;
							break;
					}
					break;
					
				case 5 :	// RUNE 5 HP
					$mainStat = STATS::HP;
					$mainType = 0;
					$mainVal = 2448;
					break;
					
				case 6 :	// RUNE 6
					$mainType = 1;
					switch($aMainStat){
						case 0 : // HP
						case 1 : // HP
							$mainStat = STATS::HP;
							$mainVal = 63;
							break;
						case 2 : // ATK
							$mainStat = STATS::ATK;
							$mainVal = 63;
							break;
						case 3 : // DEF
							$mainStat = STATS::DEF;
							$mainVal = 63;
							break;
						case 4 :
						case 5 : // RES
							$mainStat = STATS::RES;
							$mainVal = 65;
							break;
						case 6 :
						case 7 : // PRE
							$mainStat = STATS::PRE;
							$mainVal = 80;
							break;
					}
					break;
			}
			$mainBonus = new Bonus($mainStat,$mainType,$mainVal);
			$this->set_mainStat($mainBonus);
			
			
			// Set the 4 subStat
			for ($j=0; $j<4; $j++ ){
				// Define Stats of bonus
				$bonusCode = substr($this->code,4+$j*8,8);
				$bonusStat = bindec(substr($bonusCode,0,3));
				// Define type of bonus : +X or +X%
				if ( $bonusStat == STATS::SPD ){
					$bonusType = 0;	// SPD : force +X (not +X%)
				}elseif ( $bonusStat > STATS::SPD ){
					$bonusType = 1;	// CR,CD,PRE,RES : force +X% (not +X)
				}else{
					$bonusType = bindec(substr($bonusCode,3,1));	// HP,ATK,DEF : read value in code
				}
				// Define numerical value of bonus from 5~20 (0~15 + 5)
				$bonusValue = bindec(substr($bonusCode,4,4)) + 5;
				if ( $bonusType == 0 && $bonusStat != STATS::SPD ) $bonusValue *= 25;	// +X% or +25X
				
				// save bonus on rune
				$bonus = new Bonus($bonusStat,$bonusType,$bonusValue);
				$this->set_subStat($bonus);
			}
		}
		
		
		
		// ============= GET / SET ==============================
		public function get_code(){				return $this->code;				}
		public function get_position(){			return $this->position;			}
		public function get_family(){			return $this->family;			}
		public function get_mainStat(){			return $this->mainStat;			}
		public function get_subStats(){			return $this->subStats;			}
		public function get_statsModifiers(){	return $this->statsModifiers;	}
		public function has_errors(){
			if ( count($this->tabRunesErrors) > 0 ) return true;
			return false;
		}
		
		public function set_family($f){			$this->family = $f;				}
		public function set_mainStat($m){		$this->mainStat = $m;			}
		public function set_subStat($b){		array_push($this->subStats,$b);	}
		
		
		
		// ============= RUNE VALIDATION ==============================
		// Check if rune has problem, correct it and update its binary code
		public function check_and_correct(){
			
			// Check for problem
			$this->check_validity();
			if ( count($this->tabRunesErrors) > 0 ){
				foreach($this->tabRunesErrors as $index){
					
					// Delete sub
					$this->subStats[$index] = null;
					$this->tabRunesKeys[$index] = -1;
					
					// Find valid sub
					$subIsProblem = true;
					do{
						$stats = mt_rand(0,3);
						$type = mt_rand(0,1);
						$key = $stats + 10*$type;
						$subIsProblem = false;
						
						foreach($this->tabRunesKeys as $comp){
							if ($key == $comp)	$subIsProblem = true;
						}
					}while($subIsProblem);
					
					// save sub
					$val = mt_rand(0,15)+5;
					$s = new Bonus($stats,$type,$val);
					$this->subStats[$index] = $s;
					$this->tabRunesKeys[$index] = $key;
					
					// Rewrite binary code of rune with new sub
					$newCodePart = str_pad(decbin($stats),3,"0",STR_PAD_LEFT).$type.str_pad(decbin($val-5),4,"0",STR_PAD_LEFT);
					$code = $this->code;
					$codeIndex = 4 + 8*$index;
					$newCode = substr($code,0,$codeIndex);
					$newCode .= $newCodePart;
					$newCode .= substr($code,$codeIndex+8);
					$this->code = $newCode;
				}
				return true;
			}else{
				return false;
			}
		}
		
		// Check if there are doubles in rune's sub
		// return array of positions of sub in double (empty array if no problem)
		public function check_validity(){
			$this->tabRunesKeys = array();
			$this->tabRunesErrors = array();
			$key_main = $this->mainStat->get_stat() + $this->mainStat->get_type()*10;
			array_push($this->tabRunesKeys,$key_main);
			$i = 0;
			foreach ($this->subStats as $sub){
				$key_stats = $sub->get_stat() + $sub->get_type()*10;
				foreach($this->tabRunesKeys as $comp){
					if ($key_stats == $comp){
						array_push($this->tabRunesErrors,$i);
						break;
					}
				}
				array_push($this->tabRunesKeys,$key_stats);
				$i++;
			}
		}
		
		
		// Sum up all bonus (main + sub)
		// Results are stored in array (HP+ , HP+% , ATK+ , ATK+% , ... )
		private function calculate_stats_modifiers(){
			$this->statsModifiers = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
			
			$index = $this->mainStat->get_stat() * 2 + $this->mainStat->get_type();
			$this->statsModifiers[$index] += $this->mainStat->get_value();
			
			foreach ( $this->subStats as $sub ){
				$index = $sub->get_stat() * 2 + $sub->get_type();
				$this->statsModifiers[$index] += $sub->get_value();
			}
		}
		
		
		
		// ============= DISPLAY ==============================
		public function display(){
			echo RUNEFAMILY::get_name($this->family)." (".$this->position.")<br>";
			$this->mainStat->display();
			foreach ($this->subStats as $b){
				echo "<br><span class='sub'>";
				$b->display();
				echo "</span>";
			}
			/*if ( count($this->tabRunesErrors) > 0 )	echo "<br> ! ! !";
			echo "<br><table>";
			for ($i=0; $i<7; $i++){
				echo "<tr><td>".STATS::get_short_name($i)."</td><td>+".$this->statsModifiers[$i*2]."</td><td>+".$this->statsModifiers[$i*2+1]."%</td></tr>";
			}
			echo "</table>";*/
		}
		
		public function display_code(){
			echo substr($this->code,0,4)." ".substr($this->code,4,8)." ".substr($this->code,12,8)." ".substr($this->code,20,8)." ".substr($this->code,28);
		}
	}
	
	// Solo Bonus (Stats,type,value)
	class Bonus{
		
		private $stats;
		private $type;
		private $value;
		
		function __construct($s,$t,$v){
			$this->stats = $s;
			$this->type = $t;
			$this->value = $v;
		}
		
		public function get_stat(){return $this->stats;}
		public function get_type(){return $this->type;}
		public function get_value(){return $this->value;}
		
		public function set_stat($s){$this->stats = $s;}
		public function set_type($t){$this->type = $t;}
		public function set_value($v){$this->value = $v;}
		
		public function display(){
			echo $this->toString();
		}
		
		public function toString(){
			$s = STATS::get_short_name($this->stats)." +".$this->value;
			if ( $this->type == "1" ) $s .= "%";
			return $s;
		}
	}
?>
<?
	include ("constants.php");
	include ("Skill.php");
	include ("Rune.php");
	include ("Combat.php");
	
	class Monster{
		
		private $name;
		private $element;	// ELMT
		private $stats;		// STATS
		private $skills;	
		private $runes;	
		private $statModifiers;
		
		private $maxHP = 0;
		private $fightStats = array();
		private $buffList = array();
		private $debuffList = array();
		private $cooldowns = array();
		
		function __construct($aNom,$aElement,$aStats,$aRunage,$aSkills) {
			$this->name = $aNom;
			if ( $aElement >= 0 && $aElement <= 5 ){
				$this->element = $aElement;
			}
			if ( sizeof($aStats) == 8 ){
				$this->stats = $aStats;
			}
			for ( $i=0; $i<5; $i++ ){
				if ( $aSkills[$i] ){
					$this->skills[$i] = $aSkills[$i];
					$this->cooldowns[$i] = 0;
				}
			}
			$runage = new Runage($aRunage);
			$this->runes = $runage;
			
			$this->calculate_stats_modifiers();
		}
		
		public function get_name(){			return $this->name;				}
		public function get_element(){		return $this->element;			}
		public function get_base_stats(){	return $this->stats;			}
		//public function get_skill($id){		return $this->skills[$id];		}
		public function get_fight_stats(){	return $this->fightStats;		}
		public function get_statsMod(){		return $this->statModifiers;	}
		public function get_buff(){			return $this->buffList;			}
		public function get_debuff(){		return $this->debuffList;		}
		
		
		
		// Aggregate bonus from runage (family + sub)
		private function calculate_stats_modifiers(){
			$this->statModifiers = array(0,0,0,0,0,0,0,0);
			// Each runageSubBonus
			$i = 0;
			foreach($this->runes->get_stats_modifiers() as $mod){
				$s = floor($i/2);
				if ( $i % 2 == 0 || $s > 3 ){
					$this->statModifiers[$s] += $mod;
				}else{
					$pc = round( $mod * $this->stats[$s] / 100 );
					$this->statModifiers[$s] += $pc;
				}
				$i++;
			}
			// Each runageFamilyBonus
			$i = 0;
			foreach($this->runes->get_family_modifiers() as $mod){
				$s = floor($i/2);
				if ( $i % 2 == 0 || $i > 3 ){
					$this->statModifiers[$s] += $mod;
				}else{
					$pc = round( $mod * $this->stats[$s] / 100 );
					$this->statModifiers[$s] += $pc;
				}
				$i++;
			}
			
			// Update final stats
			for ( $i=0; $i<8; $i++ ){
				$v = $this->stats[$i] + $this->statModifiers[$i];
				if ( ($i==STATS::CR || $i==STATS::PRE || $i==STATS::RES) && $v > 100 ) $v = 100;
				$this->fightStats[$i] = $v;
				if ( $i == STATS::HP ){
					$this->maxHP = $v;
					$this->fightStats[8] = $v;
				}
			}
		}
		
		public function display(){
			echo "
				<div class='monsterID'>
					<b>".$this->name."</b><br>
					<span>(".ELMT::get_name($this->element).")</span>
					<br><br>
					<table cellspacing=0 border=0 width=100%>";
			// Stats
			for ($i=0;$i<4;$i++){
				echo "
					<tr>
						<td title='".STATS::get_long_name($i)."' class='statName'>".STATS::get_short_name($i)."</td><td class='statVal'>".$this->stats[$i]."</td><td class='statMod'>+".$this->statModifiers[$i]."</td>
						<td title='".STATS::get_long_name($i+4)."' class='statName'>".STATS::get_short_name($i+4)."</td><td class='statVal'>";
						$v = $this->stats[$i+4]+$this->statModifiers[$i+4];
						if ( $i != 1 && $v > 100 ) $v = 100;
						echo "$v</td><td class='statMod'>&nbsp;</td>
					</tr>";
			}
			echo "
					</table>
					<br><br>";
			
			// Skills
			echo "
					<div class='skills'>";
			foreach ( $this->skills as $skill){
				echo "
						<span>".$skill->get_name()."</span>";
			}
			echo "
					</div><br><br>";
			
			// Runes
			$this->runes->display();
			echo"
				</div>";
		}
		public function display_infight(){
			$currentHP = $this->fightStats[STATS::HP];
			$perCentHP = round( $currentHP * 100 / $this->maxHP );
			$mainStats = "";
			foreach ( $this->runes->get_main_stats() as $st ){	$mainStats .= STATS::get_short_name($st). " / ";	}
			$mainStats = substr($mainStats,0,-3);
			$families = "";
			foreach ( $this->runes->get_families() as $family ){$families .= $family." "; }
			$buffsdebuffs = "";
			foreach ( $this->debuffList as $debuff ){	$buffsdebuffs .= "<div class='debuff' title='".DEBUFF::get_name($debuff["type"])."'>".$debuff["turns"]."</div>";	}
			foreach ( $this->buffList as $buff ){		$buffsdebuffs .= "<div class='buff' title='".BUFF::get_name($buff["type"])."'>".$buff["turns"]."</div>";	}
			
			echo "<div class='infightMonster ".ELMT::get_name($this->element)."'>";
			echo "<table cellspacing=0><tr><td colspan=2>".$this->name."</td></tr>";
			echo "<tr><td colspan=2>".$families."<br>".$mainStats."</td></tr>";
			
			echo "<tr><td colspan=2>".$buffsdebuffs."</td></tr>";
			
			echo "<tr><td class='remainingHP' width='".$perCentHP."%'></td><td class='lostHP'></td></tr>";
			echo "<tr><td colspan=2>".$currentHP." / ".$this->maxHP."</td></tr></table>";
			echo "</div>";
		}
		
		////////////////////////////////////////////////////////////
		//////////////////// COMBAT ////////////////////////////////
		////////////////////////////////////////////////////////////
		
		// Choose a skill (not in cooldown)
		public function choose_skill(){
			$tabSkill = array();
			foreach ( $this->cooldowns as $id => $cd ){
				if ( $cd == 0 ){
					array_push($tabSkill,$id);
				}
			}
			if ( count($tabSkill) > 1 ){
				$skillId = $tabSkill[mt_rand(0,count($tabSkill)-1)];
			}else{
				$skillId = $tabSkill[0];
			}
			$this->cooldowns[$skillId] = $this->skills[$skillId]->get_cooldown();
			return $this->skills[$skillId];
		}
		
		// Decrease skills cooldown
		public function cooldown(){
			// Skills
			for ( $i=0; $i<5; $i++ ){
				$cd = $this->cooldowns[$i];
				if ( $cd > 0 )
					$this->cooldowns[$i] = $cd - 1;
			}
			// active buffs
			foreach ( $this->buffList as $k => $buff ){
				if ( $buff["turns"] > 1 ){
					$this->buffList[$k]["turns"] -= 1;
				}else{
					array_splice($this->buffList,$k,1);
					// If buff was about stats : update fightStats back
				}
			}
			// active debuffs
			foreach ( $this->debuffList as $k => $debuff ){
				if ( $debuff["turns"] > 1 ){
					$this->debuffList[$k]["turns"] -= 1;
				}else{
					// apply bomb affect here
					array_splice($this->debuffList,$k,1);
					// If debuff was about stats : update fightStats back
				}
			}
		}
		
		// When the monster is hit. Rturn true if he's still alive after
		public function take_hit ( $dmg ){
			//echo $this->fightStats[STATS::HP];
			$this->fightStats[STATS::HP] -= $dmg;
			//echo "->".$this->fightStats[STATS::HP]." ";
			if ( $this->fightStats[STATS::HP] > 0 ) return true;
			return false;
		}
		
			
		// BUFF / DEBUFF
		public function add_buff($buff){
			// Check if buff is already on monster => don't add but refresh nbTurns
			foreach($this->get_buff() as $k=>$mybuff){
				if ( $mybuff["type"] == $buff["type"] ){
					$this->buffList[$k]["turns"] = $buff["turns"];
					return true;
				}
			}
			// Check number of buffs. If more than 10 => replace older buff by new one
			if ( count($this->buffList) > 9 ){
				array_shift($this->buffList);
			}
			array_push($this->buffList,$buff);
		}
		public function add_debuff($debuff){
			// Check if debuff is already on monster => don't add but refresh nbTurns
			foreach($this->get_debuff() as $k=>$mydebuff){
				if ( $mydebuff["type"] == $debuff["type"] ){
					$this->debuffList[$k]["turns"] = $debuff["turns"];
					return true;
				}
			}
			// Check number of debuffs. If more than 10 => replace older debuff by new one
			if ( count($this->debuffList) > 9 ){
				array_shift($this->debuffList);
			}
			array_push($this->debuffList,$debuff);
			// If new debuff is about stats : update fightStats
		}
		
		// Check if monster has constant damage debuff and apply it
		public function apply_constant_damages(){
			foreach($this->get_debuff() as $debuff){
				if ( $debuff["type"] == DEBUFF::CONSTDMG ){
					$this->fightStats[STATS::HP] -= round($this->maxHP * 0.05);
					return true;
				}
			}
			return false;
		}
		
		// Check if monster has heal buff and apply it
		public function apply_heal_buff(){
			foreach($this->get_buff() as $buff){
				if ( $buff["type"] == BUFF::HEAL ){
					$newHP = $this->fightStats[STATS::HP] + round($this->maxHP * 0.15);
					if ( $newHp > $this->maxHP ) $newHP = $this->maxHP;
					$this->fightStats[STATS::HP] = $newHP;
					return true;
				}
			}
			return false;
		}
		
		// Check if monster is Stun, asleep or frozen
		public function isReady(){
			foreach($this->get_debuff() as $debuff){
				if ( $debuff["type"]==DEBUFF::STUN || $debuff["type"]==DEBUFF::ASLEEP || $debuff["type"]==DEBUFF::FREEZE ){
					return false;
				}
			}
			return true;
		}
	}
	
	
	
?>
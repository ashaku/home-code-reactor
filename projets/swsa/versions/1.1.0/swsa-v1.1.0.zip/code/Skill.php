<?
	// Skill Classes
	// Represent any monster skill
	// It has a list of effects
	// Effects are basic action : deal damage, heal, buff, debuff, etc
	
	class Skill{
		private $name;
		private $effects;	// SkillAction
		private $cooldown;	// int
	
		function __construct($aNom,$aEffects,$aCooldown) {
			$this->name = $aNom;
			$this->effects = $aEffects;
			$this->cooldown = $aCooldown;
		}
		public function get_name(){			return $this->name;		}
		public function get_effects(){		return $this->effects;	}
		public function get_cooldown(){		return $this->cooldown;	}
	}
	
	
	class ActiveSkillEffect{
		private $type;
		private $targetSide; 	// 0:ennemy ; 1:ally
		private $targetZone; // 0:unique ; 1:multi ; 2:all
		
		function __construct($aType,$aSide,$aZone) {
			$this->type = $aType;
			$this->targetSide = $aSide;
			$this->targetZone = $aZone;
		}
		
		public function get_type(){	return $this->type;	}
		public function get_targetSide(){	return $this->targetSide;	}
		public function get_targetZone(){	return $this->targetZone;	}
		public function execute(){}
	}
	
	class Damage extends ActiveSkillEffect{
		private $formula;
		private $nbHits;
		
		function __construct($aZone,$aFormula,$aType=SKILLEFFECT::damage,$aNbHits=1){
			parent::__construct($aType,0,$aZone);
			$this->formula = $aFormula;
			$this->nbHits = $aNbHits;
		}
		
		public function execute($attackingMonsterStats){
			// decode formula
			$operand1 = 0;
			$operand2 = 0;
			$operator1 = "";
			$operator2 = "";
			$total = 0;
			//echo "<br><br>Start Decode Formula : ";print_r($this->formula);
			foreach($this->formula as $i => $line){
				//echo "<br> &nbsp; line $i : ";print_r($line);
				
				// for operand
				if ( $i % 2 == 0 ){
					
					// If unique value
					if ( count($line) == 1 ){
						// decode stat
						$data = $line[0];
						//echo "<br> &nbsp; Unique value : ".$data;
						if ( !is_numeric($data) ){
							switch($data){
								case "HP": $lineVal = $attackingMonsterStats[STATS::HP];	break;
								case "ATK": $lineVal = $attackingMonsterStats[STATS::ATK];	break;
								case "DEF": $lineVal = $attackingMonsterStats[STATS::DEF];	break;
								case "SPD": $lineVal = $attackingMonsterStats[STATS::SPD];	break;
								case "MAXHP": $lineVal = $attackingMonsterStats[STATS::MAXHP];	break;
							}
							//echo " => ".$lineVal;
						}else{
							$lineVal = $data;
						}
						
						
					// If operand is formula itself : apply same logic on a second level
					}else{
						
						$lineVal = 0;
						//echo "<br> &nbsp; Array value : compute";
						foreach($line as $j => $data){
							//echo "<br> &nbsp; &nbsp; $j. $data";
							
							if ( $j % 2 == 0 ){
								//operand
								//decode stat
								if ( !is_numeric($data) ){
									switch($data){
										case "HP": $numval = $attackingMonsterStats[STATS::HP];		break;
										case "ATK": $numval = $attackingMonsterStats[STATS::ATK];	break;
										case "DEF": $numval = $attackingMonsterStats[STATS::DEF];	break;
										case "SPD": $numval = $attackingMonsterStats[STATS::SPD];	break;
										case "MAXHP": $numval = $attackingMonsterStats[STATS::MAXHP];	break;
									}
									//echo " => ".$numval;
								}else{
									$numval = $data;
								}
								if ( $j == 0 ){
									//store first
									$lineVal = $numval;
									//echo " :: Store $numval as first subline value";
								}else{
									//calculate next
									//echo " :: Compute $lineVal ";
									switch ($operator2){
										case "+": $lineVal += $numval; break;
										case "-": $lineVal -= $numval; break;
										case "*": $lineVal *= $numval; break;
										case "/": $lineVal /= $numval; break;
										case "%": $lineVal = $lineVal * $numval / 100; break;
									}
									//echo " => $lineVal";
								}
							}else{
								$operator2 = $data;
								//echo " :: update operator2";
							}
						}
					}
					
					// If first value
					if ( $i == 0 ){
						
						// store
						$total = $lineVal;
						//echo "<br> &nbsp; Store $lineVal as first line value";
					}else{
						
						// For next values : update total with last operand and current operand
						//echo "<br> &nbsp; Compute $total ";
						switch ($operator1){
							case "+": $total += $lineVal; break;
							case "-": $total -= $lineVal; break;
							case "*": $total *= $lineVal; break;
							case "/": $total /= $lineVal; break;
							case "%": $total = $total * $lineVal / 100; break;
						}
						//echo " => $total";
					}
				
				// for operator
				}else{
					// simply store it
					$operator1 = $line[0];
					//echo " update operator1";
				}
			}
			//echo "<br> => total damage : ".round ( $total );
			return round ( $total );
		}
	}
	
	class DamageDebuff extends Damage{
		private $debuffType;
		private $nbTurns;
		private $perCent;
		
		function __construct($aZone,$aFormula,$aDebuffType,$aNbTurns,$aPerCent,$aNbHits=1){
			parent::__construct($aZone,$aFormula,SKILLEFFECT::damageDebuff,$aNbHits);
			$this->debuffType = $aDebuffType;
			$this->nbTurns = $aNbTurns;
			$this->perCent = $aPerCent;
		}
		
		public function execute($attackingMonsterStats){
			$dmg = parent::execute($attackingMonsterStats);
			return array($dmg,$this->perCent,$this->debuffType,$this->nbTurns);
			/*if ( mt_rand(1,100) > $this->perCent ){
				// Debuff not applied
				return array($dmg);
			}else{
				// Apply debuff on ennemy
				return array($dmg,$this->perCent,$this->debuffType,$this->nbTurns);
			}*/
		}
	}
?>
<?
	// 
	//
	
	
	class Combat{
		
		private $numTurn;
		private $team1;
		private $team2;
		private $speedCounter;
		private $team1dead;
		private $team2dead;
		private $verbose;
		
		function __construct($aTeam1,$aTeam2,$aVerbose=false) {
			$this->team1 = $aTeam1;
			$this->team2 = $aTeam2;
			$this->speedCounter = array();
			$this->team1dead = array();
			$this->team2dead = array();
			$this->verbose = $aVerbose;
			$this->run();
		}
		
		// Start the fight
		public function run(){
			
			$this->numTurn = 0;
			
			// init speed counters
			foreach ( $this->team1 as $id => $mon )	$this->speedCounter[$id] = 0;
			foreach ( $this->team2 as $id => $mon )	$this->speedCounter[$id+10] = 0;
			
			// Init effects (runes SHIELD IMMUNITY ...)
			
			// While both team alive
			$watchdog = 0;
			do{
				// Increase attack bar for each monster of each team
				$playTurn = false;
				foreach ( $this->team1 as $id => $mon ){
					$tick = $mon->get_fight_stats()[STATS::SPD] * 0.07;
					$newVal = $this->speedCounter[$id] + $tick;
					$this->speedCounter[$id] = $newVal;
					if ( $newVal > 100 ) $playTurn = true;
				}
				foreach ( $this->team2 as $id => $mon ){
					$tick = $mon->get_fight_stats()[STATS::SPD] * 0.07;
					$newVal = $this->speedCounter[$id+10] + $tick;
					$this->speedCounter[$id+10] = $newVal;
					if ( $newVal > 100 ) $playTurn = true;
				}
				// Play a turn
				if ( $playTurn ){	$this->play_next_turn();	}
				$watchdog++;
			}while( count($this->team1) && count($this->team2) && $this->numTurn < 99 && $watchdog < 999 );
		}
		
		public function play_next_turn(){
			
			// find next monster to play
			$this->numTurn ++;
			$playingTeam = 0;
			$opposingTeam = 0;
			arsort($this->speedCounter);
			if ( $this->verbose ){
				$this->display();
				echo "<br>".$this->numTurn.". ";
			}
			foreach($this->speedCounter as $k => $spd){	$fastest = $k;	break;	}
			$this->speedCounter[$k] = 0;	// Reinit speed bar of monster
			if ( $k > 9 ){
				$playingTeam = 2;
				$opposingTeam = 1;
				$idMonster = $k-10;
				$monster = $this->team2[$idMonster];
			}else{
				$playingTeam = 1;
				$opposingTeam = 2;
				$idMonster = $k;
				$monster = $this->team1[$idMonster];
			}
			if ( $this->verbose ) echo $monster->get_name()." ";
			
			//////////////// STARTING TURN ACTIONS ////////////
			// Init skill execution
			$monsterStats = $monster->get_fight_stats();
			$monsterElmt = $monster->get_element();
			$isReady = $monster->isReady();
			
			// TODO : Execute monster passive skill
			
			// Apply buff:heal or debuff:constDamage
			if ( $monster->apply_constant_damages() ){
				if ( $this->verbose ) echo "(-5%MAXHP) ";
			}
			if ( $monster->apply_heal_buff() ){
				if ( $this->verbose ) echo "(+15%MAXHP) ";
			}
			
			// Cooldown skills and all active buff / debuff
			$monster->cooldown();
			
			// Check if monster is Stun, asleep or frozen
			if ( $isReady ){
			
				//////////////// MONSTER PLAY ITS TURN ////////////
				// Choose Active skill to execute (will update skill cooldown)
				$skill = $monster->choose_skill();
				if ( $this->verbose ) echo "use :".$skill->get_name().": ";
				
				// Execute each effects of skill
				foreach ( $skill->get_effects() as $effect ){
					
					$targetZone = $effect->get_targetZone();
					switch ( $effect->get_type() ){
						case SKILLEFFECT::damage :
												// decode skill dmg formula to get a %atk
												$dmg = $effect->execute($monsterStats);
												$this->apply_skill_damage($dmg,$opposingTeam,$targetZone,$monsterStats,$monsterElmt,false,false);
												break;
												
						case SKILLEFFECT::damageDebuff :
												// get array ( dmg [,debuff,nbTurns] )
												$infos = $effect->execute($monsterStats);
												$dmg = $infos[0];
												$debuff = array("perCent"=>$infos[1],"type"=>$infos[2],"turns"=>$infos[3]);
												$this->apply_skill_damage($dmg,$opposingTeam,$targetZone,$monsterStats,$monsterElmt,$debuff,false);
												break;
						
					}
				}
			}
		}
		
		// DAMAGE-RELATED FUNCTION
		///////////////////////////////////////////////
		private function apply_skill_damage($dmg,$opposingTeam,$targetZone,$attackingMonsterStats,$attackingMonsterElmt,$debuff,$ignoreDef){
			switch($targetZone){
				case TARGET::UNIQUE :	if ( $opposingTeam == 1 ){
											$id_target = mt_rand(0,count($this->team1)-1);
											$defMonster = $this->team1[$id_target];
											$targetKilled = $this->deal_damage($dmg,$defMonster,$attackingMonsterStats[STATS::CR],$attackingMonsterStats[STATS::CD],$attackingMonsterElmt,$ignoreDef);
											if ( $targetKilled ){
												$this->remove_monster($id_target,$opposingTeam);
											}else{
												if ( $debuff ){
													$this->apply_debuff($debuff,$defMonster,$attackingMonsterStats[STATS::PRE]);
												}
											}
										}elseif ( $opposingTeam == 2 ){
											$id_target = mt_rand(0,count($this->team2)-1);
											$defMonster = $this->team2[$id_target];
											$targetKilled = $this->deal_damage($dmg,$defMonster,$attackingMonsterStats[STATS::CR],$attackingMonsterStats[STATS::CD],$attackingMonsterElmt,$ignoreDef);
											if ( $targetKilled ){
												$this->remove_monster($id_target,$opposingTeam);
											}else{
												if ( $debuff ){
													$this->apply_debuff($debuff,$defMonster,$attackingMonsterStats[STATS::PRE]);
												}
											}
										}
										break;
										
				case TARGET::MULTI :
										break;
										
				case TARGET::ALL :		if ( $opposingTeam == 1 ){
											foreach ( $this->team1 as $id_target => $defMonster ){
												echo "<br> &nbsp; &nbsp; &nbsp; * ";
												$targetKilled = $this->deal_damage($dmg,$defMonster,$attackingMonsterStats[STATS::CR],$attackingMonsterStats[STATS::CD],$attackingMonsterElmt,$ignoreDef);
												if ( $targetKilled ){
													$this->remove_monster($id_target,$opposingTeam);
												}else{
													if ( $debuff ){
														$this->apply_debuff($debuff,$defMonster,$attackingMonsterStats[STATS::PRE]);
													}
												}
											}
										}elseif ( $opposingTeam == 2 ){
											foreach ( $this->team2 as $id_target => $defMonster ){
												echo "<br> &nbsp; &nbsp; &nbsp; * ";
												$targetKilled = $this->deal_damage($dmg,$defMonster,$attackingMonsterStats[STATS::CR],$attackingMonsterStats[STATS::CD],$attackingMonsterElmt,$ignoreDef);
												if ( $targetKilled ){
													$this->remove_monster($id_target,$opposingTeam);
												}else{
													if ( $debuff ){
														$this->apply_debuff($debuff,$defMonster,$attackingMonsterStats[STATS::PRE]);
													}
												}
											}
										}
										break;
			}
		}
		
		private function deal_damage ( $dmg, $defMonster, $criticalRate, $criticalDamages, $attackingMonsterElmt, $ignoreDef ){
			
			if ( $this->verbose ) echo "(dmg=".$dmg;
			
			// Critical ?
			if ( mt_rand(0,100) < $criticalRate ){
				$dmg *= ( 1 + $criticalDamages / 100 );
				if ( $this->verbose ) echo " +".$criticalDamages."%";
			}
			
			// Elemental advantage ?
			$adv = $this->has_advantage ( $attackingMonsterElmt, $defMonster->get_element() );
			if ( $adv == 1){
				$dmg *= 1.3;
				if ( $this->verbose ) echo " +30%";
			}elseif ( $adv == -1){
				$dmg *= 0.7;
				if ( $this->verbose ) echo " -30%";
			}
			
			// Defense
			$ennemyDef = $defMonster->get_fight_stats()[STATS::DEF];
			if ( $ignoreDef )	$ennemyDef = 0;
			$defFactor = 1000 / (1140 + 3.5*$ennemyDef);
			$dmg = round($dmg * $defFactor);
			if ( $this->verbose ) echo ") on ".$defMonster->get_name()." (x".round($defFactor,2).") => !".$dmg."!" ;
			
			// Hit
			if ( $defMonster->take_hit($dmg) ){
				// Monster survived damamges
				
				// possible counter ?
				// (if target has revenge rune, or counter buff)
				return false;
			}else{
				// Monster is dead
				if ( $this->verbose ) echo " dead";
				return true;
			}
		}
		
		private function apply_debuff($debuff,$defMonster,$accuracy){
			// Check Immunity
			
			// Check PRE/RES
			$ennemyRes = $defMonster->get_fight_stats()[STATS::RES];
			$chanceToResist = $ennemyRes - $accuracy;
			if ( $chanceToResist < 15 ) $chanceToResist = 15;
			$chanceToApply = (100-$chanceToResist) * $debuff["perCent"] / 100;
			if ( mt_rand(1,100) < $chanceToApply ){
				// Apply budebuff
				if ( $this->verbose ) echo " apply ".DEBUFF::get_name($debuff["type"])." for ".$debuff["turns"]." turns";
				$defMonster->add_debuff($debuff);
			}
		}
		
		// When a monster die => move it from "team" array to "dead" array
		private function remove_monster($id,$team){
			if ( $team == 1 ){
				$mon = array_splice ( $this->team1, $id, 1 );
				array_push ( $this->team1dead, $mon );
				$this->speedCounter[$id] = 0;
			}elseif ( $team == 2 ){
				$mon = array_splice ( $this->team2, $id, 1 );
				array_push ( $this->team2dead, $mon );
				$this->speedCounter[$id+10] = 0;
			}
		}
		
		
		private function has_advantage($elmt1,$elmt2){
			//echo "has_advantage ( ".ELMT::get_name($elmt1).", ".ELMT::get_name($elmt2)." )<br>";
			if (
				($elmt1 == ELMT::water && $elmt2 == ELMT::fire) ||
				($elmt1 == ELMT::fire && $elmt2 == ELMT::wind) ||
				($elmt1 == ELMT::wind && $elmt2 == ELMT::water) ||
				($elmt1 == ELMT::dark && $elmt2 == ELMT::light) ||
				($elmt1 == ELMT::light && $elmt2 == ELMT::dark)
			){
				//echo ELMT::get_name($elmt1)." > ".ELMT::get_name($elmt2);
				return 1;
			}elseif (
				($elmt1 == ELMT::water && $elmt2 == ELMT::wind) ||
				($elmt1 == ELMT::fire && $elmt2 == ELMT::water) ||
				($elmt1 == ELMT::wind && $elmt2 == ELMT::fire)
			){
				//echo ELMT::get_name($elmt1)." < ".ELMT::get_name($elmt2);
				return -1;
			}else{
				//echo ELMT::get_name($elmt1)." = ".ELMT::get_name($elmt2);
				return 0;
			}
		}
		
		public function get_winner(){
			if ( count($this->team1) == 0 && count($this->team2) > 0 ) return 2;
			if ( count($this->team2) == 0 && count($this->team1) > 0 ) return 1;
			return 0;
		}
		
		public function display_team ( $team ){
			echo "<div class='team'>";// TEAM ".$team." :<br>";
			if ( $team == 1 ){
				foreach($this->team1 as $mon) $mon->display_infight();
			}elseif ( $team == 2 ){
				foreach($this->team2 as $mon) $mon->display_infight();
			}
			echo "</div>";
		}
	
		public function display(){
			echo "<div class='fight'><table><tr><td>";
			$this->display_team(1);
			echo "</td></tr><tr><td style='text-align:center'>VS</td></tr><tr><td>";
			$this->display_team(2);
			echo "</td></tr></table></div>";
		}
	}
	
	
	
?>
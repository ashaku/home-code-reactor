<? 
	// VISUALISATION DES TESTS

	require('../code/swsa.php');
	require('tests.php');
?>
<!DOCTYPE html>
<html lang='fr'>
	<head>
		<title>SWSA</title>
		<link rel="stylesheet" type="text/css" href="screen.css">
		<meta charset="utf-8">
	</head>
	<body>
	
<?
	$testRune = 0;
	$testRunage = 0;
	$testSkill = 0;
	$testMon = 1;
	$testFight = 0;
	
	 
	
	
	if ($testSkill){
		
		$skillName = "Mega Smash";
		$targetZone = 10;	// 10:unique ; 11:multi ; 12:all
		$dmgFormula = array(array("SPD","+",210),array("/"),array(0.7),array("%"),array("ATK"));
		$nbHits = 1;
		$debuffType = DEBUFF::CONSTDMG;
		$nbTurns = 2;
		$perCent = 50;
		$constDamageEffect = new DamageDebuff($targetZone,$dmgFormula,$debuffType,$nbTurns,$perCent,$nbHits);
		$skillEffects = array($constDamageEffect);
		$skillCooldown = 1;
		$megaSmash = new Skill($skillName,$skillEffects,$skillCooldown);
		
		$skillName = "Super Crush";
		$targetZone = 12;	// 10:unique ; 11:multi ; 12:all
		$dmgFormula = array(array(16,"%","MAXHP"),array("+"),array(120,"%","ATK"));
		$debuffType = DEBUFF::STUN;
		$nbTurns = 1;
		$perCent = 30;
		$StunDamageEffect = new DamageDebuff($targetZone,$dmgFormula,$debuffType,$nbTurns,$perCent,$nbHits);
		$skillEffects = array($StunDamageEffect);	// SkillAction
		$skillCooldown = 4;
		$superCrush = new Skill($skillName,$skillEffects,$skillCooldown);
		
		
					$skillName = "Conversion of Magic";
					$targetZone = 12;	// 10:unique ; 11:multi ; 12:all
					$nbCleanse = 1;		// 0:all ; n:n
					$cleanseEffect = new Cleanse();
					$skillEffects = array($cleanseEffect);	// SkillAction
					$skillCooldown = 1;
					$active = false;
		
		$name = "Veromos";
		$element = ELMT::dark;
		$stats = array(9225,769,758,100,15,50,0,15);
		$skills = array($megaSmash,$superCrush);
		$runeCode = "";
		$mains = "11100110";	// SPD CR PRE
		$rune1 = "000000000000000100000011000001000000";	// Energy / Atq+ / HP+ HP+% Atq+% Def+
		$rune2 = "000001010000100100001011000011010000";	// Energy / Vit+ / Def+% CR+% CD+% Pre+%
		$rune3 = "110011110000000000000001000000100000";	// Fatal / Def+ / Res+% HP+ HP+% Atq+
		$rune4 = "110000110000010000000101000001100000";	// Fatal / CR+% / Atq+% Def+ Def+% Vit+
		$rune5 = "110010010000101100001101000011110000";	// Fatal / HP+ / CR+% CD+% Pre+% Res+%
		$rune6 = "110000010000001000000011000001010000";	// Fatal / Pre+% / HP+% Atq+ Atq+% Def+%
		//$runeCode = $mains.$rune1.$rune2.$rune3.$rune4.$rune5.$rune6;
		// Aleatoire
		for ( $i=0; $i<224; $i++ )	$runeCode .= mt_rand(0,1);
		
		$m = new Monster($name,$element,$stats,$runeCode,$skills);
		$fightStats = $m->get_fight_stats();
		
		// Display
		$m->display();
		echo "<br><br>".$megaSmash->get_name()." : ";
		$res = $constDamageEffect->execute($fightStats);
		echo "<br>".$res[0]." dmg";
		echo "<br>can apply ".DEBUFF::get_name($res[2])." for ".$res[3]." turns with ".$res[1]."%";
		
		echo "<br><br>".$superCrush->get_name()." : ";
		$res = $StunDamageEffect->execute($fightStats);
		echo "<br>".$res[0]." dmg";
		echo "<br>can apply ".DEBUFF::get_name($res[2])." for ".$res[3]." turns with ".$res[1]."%";
	}
	
	
	// Test Rune
	if ( $testRune ){
		$position = 1;
		$family = RUNEFAMILY::Energy;
		$runeMain = STATS::HP;
		for ( $i=0; $i<12; $i++ )	$runeCode .= mt_rand(0,1);
		$runeCode = "000001010011";
		$rune = new Rune($position,$family,$runeMain,$runeCode);
		$rune->display_code();
		echo "<br>";
		$rune->display();
	}
	
	
	// Test runage
	if ( $testRunage ){
		
		// Runage test
		$mains = "11011011";	// SPD CR PRE
		$families = "0000011000000";	// 4 fatale 2 energy
		$rune1 = "100101110111";	// CR CD Pre Res
		$rune2 = "100101110111";	// CR CD Pre Res
		$rune3 = "000001010011";	// HP Atq Def Vit
		$rune4 = "000001010011";	// HP Atq Def Vit
		$rune5 = "100101110111";	// CR CD Pre Res
		$rune6 = "000001010011";	// HP Atq Def Vit
		//$runageCode = $mains.$families.$rune1.$rune2.$rune3.$rune4.$rune5.$rune6;
		$runageCode = "";
		for ( $i=0; $i<93; $i++ )	$runageCode .= mt_rand(0,1);
		
		echo "<br><br>RUNAGE TEST<br>";
		//echo "Code : ".$runageCode."<br>";
		$r = new Runage($runageCode);
		$r->display();
	}


	// Test Monstre
	if ( $testMon ){
		
		$runeCode = "";
		$mains = "11011011";	// SPD CR PRE
		$families = "0000000100000";	// 4 fatale 2 energy
		$rune1 = "100101110111";	// CR CD Pre Res
		$rune2 = "100101110111";	// CR CD Pre Res
		$rune3 = "000001010011";	// HP Atq Def Vit
		$rune4 = "000001010011";	// HP Atq Def Vit
		$rune5 = "100101110111";	// CR CD Pre Res
		$rune6 = "000001010011";	// HP Atq Def Vit
		$runeCode = $mains.$families.$rune1.$rune2.$rune3.$rune4.$rune5.$rune6;
		// Aleatoire
		//for ( $i=0; $i<36; $i++ )	$runeCode .= mt_rand(0,1);
		
		$vero = MonsterLib::load_monster("Veromos",$runeCode);
		$vero->display();

		
		echo "<u>Base Stats :</u> "; print_r ($vero->get_base_stats());
		echo "<br>Runes Modifiers : "; print_r ($vero->get_runes_mod());
		echo "<br>Runes Stats : "; print_r ($vero->get_runes_stats());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		
		// lead skill
		$leadSkill = $vero->get_leadSkill();
		echo "<br><br><u>Leader SKill :</u> ";
		print_r($leadSkill);
		$vero->add_leader_skill_bonus($leadSkill);
		echo "<br>Runes Stats : "; print_r ($vero->get_runes_stats());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		
		//take_hit
		$dmg = 5992;
		echo "<br><br><u>Take hit :</u> $dmg damages";
		$vero->take_hit($dmg);
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		
		// BUFF / DEBUFF
		//add debuff on stats
		$debuffAtk = array("perCent"=>50,"type"=>DEBUFF::LOWATK,"turns"=>2);
		$debuffDef = array("perCent"=>25,"type"=>DEBUFF::LOWDEF,"turns"=>3);
		$debuffSpd = array("perCent"=>75,"type"=>DEBUFF::LOWSPD,"turns"=>1);
		echo "<br><br><u>Add LOWATK, LOWDEF, LOWSPD debuffs :</u>";
		echo "<br>debuff : "; print_r($vero->get_debuffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		$vero->add_debuff($debuffAtk);
		$vero->add_debuff($debuffDef);
		$vero->add_debuff($debuffSpd);
		echo "<br>debuff : "; print_r($vero->get_debuffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		
		//cleanse (remove debuff)
		echo "<br><br><u>Cleanse 1 :</u> ";
		$vero->remove_debuff();
		echo "<br>debuff : "; print_r($vero->get_debuffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		echo "<br><br><u>Cleanse 2 :</u> ";
		$vero->remove_debuff();
		echo "<br>debuff : "; print_r($vero->get_debuffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		echo "<br><br><u>Cleanse 3 :</u> ";
		$vero->remove_debuff();
		echo "<br>debuff : "; print_r($vero->get_debuffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		
		//add buff
		$buffAtk = array("perCent"=>50,"type"=>BUFF::RAISEATK,"turns"=>2);
		$buffSpd = array("perCent"=>25,"type"=>BUFF::RAISESPD,"turns"=>3);
		$buffDef = array("perCent"=>75,"type"=>BUFF::RAISEDEF,"turns"=>1);
		$buffCr = array("perCent"=>75,"type"=>BUFF::RAISECR,"turns"=>1);
		echo "<br><br><u>Add RAISEATK, RAISESPD, RAISEDEF, RAISECR buffs :</u>";
		echo "<br>buff : "; print_r($vero->get_buffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		$vero->add_buff($buffAtk);
		$vero->add_buff($buffDef);
		$vero->add_buff($buffSpd);
		$vero->add_buff($buffCr);
		echo "<br>buff : "; print_r($vero->get_buffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		
		//strip (del buff)
		echo "<br><br><u>Strip 1 :</u> ";
		$vero->remove_buff();
		echo "<br>buff : "; print_r($vero->get_buffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		echo "<br><br><u>Strip 2 :</u> ";
		$vero->remove_buff();
		echo "<br>buff : "; print_r($vero->get_buffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		echo "<br><br><u>Strip 3 :</u> ";
		$vero->remove_buff();
		echo "<br>buff : "; print_r($vero->get_buffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		echo "<br><br><u>Strip 4 :</u> ";
		$vero->remove_buff();
		echo "<br>buff : "; print_r($vero->get_buffs());
		echo "<br>buff modifiers : "; print_r($vero->get_buff_mod());
		echo "<br>Fight Stats : "; print_r($vero->get_fight_stats());
		
		
		// Croiser buff atk, debuff atk, strip buff atk, cleanse debuff atk
		
		
		//cumul des constDmg
	}
	
	
	if ( $testFight ){
		
		$stats = array(9225,769,758,100,15,50,0,15);
		$megaSmash = SkillLib::load_skill("MegaSmash");
		$superCrush = SkillLib::load_skill("SuperCrush");
		$convMagic = SkillLib::load_skill("ConversionOfMagic");
		$skills = array($megaSmash,$superCrush,$convMagic);
		$leaderSkill = new Bonus(STATS::HP,1,33);
	
		$runeCode = "";
		for ( $i=0; $i<224; $i++ )	$runeCode .= mt_rand(0,1);
		$mon1a = new Monster("Veromos 1-A",mt_rand(0,4),$stats,$runeCode,$skills,$leaderSkill);
		$runeCode = "";
		for ( $i=0; $i<224; $i++ )	$runeCode .= mt_rand(0,1);
		$mon1b = new Monster("Veromos 1-B",mt_rand(0,4),$stats,$runeCode,$skills,$leaderSkill);
		$runeCode = "";
		for ( $i=0; $i<224; $i++ )	$runeCode .= mt_rand(0,1);
		$mon1c = new Monster("Veromos 1-C",mt_rand(0,4),$stats,$runeCode,$skills,$leaderSkill);
		
		$runeCode = "";
		for ( $i=0; $i<224; $i++ )	$runeCode .= mt_rand(0,1);
		$mon2a = new Monster("Veromos 2-A",mt_rand(0,4),$stats,$runeCode,$skills,$leaderSkill);
		$runeCode = "";
		for ( $i=0; $i<224; $i++ )	$runeCode .= mt_rand(0,1);
		$mon2b = new Monster("Veromos 2-B",mt_rand(0,4),$stats,$runeCode,$skills,$leaderSkill);
		$runeCode = "";
		for ( $i=0; $i<224; $i++ )	$runeCode .= mt_rand(0,1);
		$mon2c = new Monster("Veromos 2-C",mt_rand(0,4),$stats,$runeCode,$skills,$leaderSkill);
		
		$team1 = array($mon1a,$mon1b,$mon1c);
		$team2 = array($mon2a,$mon2b,$mon2c);
		$combat = new Combat($team1,$team2,true);
		$winner = $combat->get_winner();
		echo "<br><br> winner : Team $winner<br>";
		$combat->display_team($winner);
	}
	
	
	if ( $testAutoLoad ){
		for ( $i=0; $i<224; $i++ )	$runeCode .= mt_rand(0,1);
		$vero = MonsterLib::load_monster("Veromos",$runeCode);
		$vero->display();
	}
	
	function display_rune_code($code){
		echo substr($code,0,4)." ".substr($code,4,8)." ".substr($code,12,8)." ".substr($code,20,8)." ".substr($code,28);
	}
	
	function has_advantage($elmt1,$elmt2){
		echo "has_advantage ( ".ELMT::get_name($elmt1).", ".ELMT::get_name($elmt2)." )<br>";
		if (
			($elmt1 == ELMT::water && $elmt2 == ELMT::fire) ||
			($elmt1 == ELMT::fire && $elmt2 == ELMT::wind) ||
			($elmt1 == ELMT::wind && $elmt2 == ELMT::water) ||
			($elmt1 == ELMT::dark && $elmt2 == ELMT::light) ||
			($elmt1 == ELMT::light && $elmt2 == ELMT::dark)
		){
			echo ELMT::get_name($elmt1)." > ".ELMT::get_name($elmt2);
			return 1;
		}elseif (
			($elmt1 == ELMT::water && $elmt2 == ELMT::wind) ||
			($elmt1 == ELMT::fire && $elmt2 == ELMT::water) ||
			($elmt1 == ELMT::wind && $elmt2 == ELMT::fire)
		){
			echo ELMT::get_name($elmt1)." < ".ELMT::get_name($elmt2);
			return -1;
		}else{
			echo ELMT::get_name($elmt1)." = ".ELMT::get_name($elmt2);
			return 0;
		}
	}
?>

	<body>
</html>

<?
	// TODO : Explain what Combat class is for
	// Basically run a fight, which is a succession of turns
	// A turn is a monster launching a skill => Get highest attackBar & choose skill
	// apply skill effects : choose target(s)
	// teams are stored in array "teams" at indexes 1 and 2
	// dead mobs go to an array "teamDeads" (same principle as teams, same index too)
	
	
	class Combat{
		
		private $numTurn;
		private $teams;
		private $speedCounter;
		private $teamDeads;
		private $verbose;
		
		function __construct($aTeam1,$aTeam2,$aVerbose=false) {
			$this->teams[1] = $aTeam1;
			$this->teams[2] = $aTeam2;
			$this->speedCounter = array();
			$this->teamDeads = array();
			$this->verbose = $aVerbose;
			$this->run();
		}
		
		// LEVEL 0 : Start the fight
		///////////////////////////////////////////////////////////////////
		// Pretty self explanatory
		public function run(){
			
			$this->numTurn = 0;
			
			// Apply leader skill
			for ( $idTeam=1; $idTeam<3; $idTeam++ ){
				if ( $leadSkill = $this->teams[$idTeam][0]->get_leadSkill() ){
					/*$leadSkillStat = $leadSkill->get_stat();
					$leadSkillType = $leadSkill->get_type();
					$leadSkillValue = $leadSkill->get_value();*/
					foreach($this->teams[$idTeam] as $id=>$mon){
						/*if ( $leadSkillType == 1 ){
							$statDelta = $mon->get_base_stat($leadSkillStat) * $leadSkillValue / 100;
						}else{
							$statDelta = $leadSkillValue;
						}*/
						$mon->add_leader_skill_bonus($leadSkill);
						
						// init speed counters
						$this->speedCounter[$id+(10*($idTeam-1))] = 0;
					}
				}
			}
			
			// Init effects (runes SHIELD IMMUNITY ...)
			
			// While both team alive
			$watchdog = 0;
			do{
				// Increase attack bar for each monster of each team
				$playTurn = false;
				for ( $idTeam=1; $idTeam<3; $idTeam++ ){
					foreach ( $this->teams[$idTeam] as $id => $mon ){
						if ( $mon != null ){
							$tick = $mon->get_fight_stats()[STATS::SPD] * 0.07;
							$newVal = $this->speedCounter[$id+(10*($idTeam-1))] + $tick;
							$this->speedCounter[$id+(10*($idTeam-1))] = $newVal;
							if ( $newVal > 100 ) $playTurn = true;
						}
					}
				}
				
				// Play a turn
				if ( $playTurn ){	$this->play_next_turn();	}
				
				// check if one team is dead
				$bothTeamAlive = true;
				//if ( count($this->team1)==count($this->team1dead) || count($this->team2)==count($this->team2dead) ) $bothTeamAlive = false;
				for ( $idTeam=1; $idTeam<=2; $idTeam++ ){				
					if ( count($this->teams[$idTeam]) == count($this->teamDeads[$idTeam]) ) $bothTeamAlive = false;
				}
				$watchdog++;
			}while( $bothTeamAlive && $this->numTurn < 99 && $watchdog < 999 );
		}
		
		
		
		
		// LEVEL 1 : Choose a skill
		/////////////////////////////////////////////////////////////////////////////////////////
		// 1 monster has reached 100 attack bar : choose and apply one of its skill for this turn
		public function play_next_turn(){
			
			// find next monster to play
			$this->numTurn ++;
			$playingTeam = 0;
			arsort($this->speedCounter);
			if ( $this->verbose ){
				$this->display();
				echo "<br>".$this->numTurn.". ";
			}
			foreach($this->speedCounter as $k => $spd){	$fastest = $k;	break;	}
			$this->speedCounter[$k] = 0;	// Reinit speed bar of monster
			if ( $k > 9 ){
				$playingTeam = 2;
				$idMonster = $k-10;
				$monster = $this->teams[2][$idMonster];
			}else{
				$playingTeam = 1;
				$idMonster = $k;
				$monster = $this->teams[1][$idMonster];
			}
			if ( $this->verbose ) echo $monster->get_name()." ";
			
			//////////////// STARTING TURN ACTIONS ////////////
			// Init skill execution
			$isReady = $monster->isReady();
			
			// Apply buff:heal or debuff:constDamage on monster
			if ( $monster->apply_constant_damages() ){
				if ( $this->verbose ) echo "(CONST DMG -5% MAXHP) ";
				if ( $monster->get_fight_stats()[STATS::HP] <= 0 )	$this->remove_monster($idMonster,$playingTeam);
			}
			if ( $monster->apply_heal_buff() ){
				if ( $this->verbose ) echo "(HEAL +15% MAXHP) ";
			}
			
			// Execute monster passive skill
			foreach ( $monster->get_skills() as $id => $skill ){
				if ( !$skill->is_active() ){
					$this->apply_skill_effect($skill,$monster,$playingTeam);
				}
			}
			
			// Cooldown skills and all active buff / debuff
			$monster->cooldown();
			
			// Check if monster is Stun, asleep or frozen
			if ( $isReady ){
			
				//////////////// MONSTER PLAY ITS TURN ////////////
				// Choose Active skill to execute (will update skill cooldown)
				$skill = $monster->choose_skill();
				if ( $this->verbose ) echo "use :".$skill->get_name().": ";
				
				// Execute each effects of skill
				$this->apply_skill_effect($skill,$monster,$playingTeam);
			}
		}
		
		
		
		
		// LEVEL 2 : Apply all effects of chosen skill
		///////////////////////////////////////////////////////////////////
		// This function is the big 'switch' for all possible skill effects
		private function apply_skill_effect($skill,$monster,$playingTeam){
			$monsterStats = $monster->get_fight_stats();
			$monsterElmt = $monster->get_element();
			$opposingTeam = $playingTeam % 2 + 1;
			
			foreach ( $skill->get_effects() as $effect ){
				
				$targetZone = $effect->get_targetZone();
				switch ( $effect->get_type() ){
					
					case EFFECT::damage :
											// decode skill dmg formula to get a %atk
											$dmg = $effect->execute($monsterStats);
											$this->apply_skill_damage($dmg,$opposingTeam,$targetZone,$monsterStats,$monsterElmt,false,false);
											break;
											
					case EFFECT::damageDebuff :
											// get array ( dmg [,debuff,nbTurns] )
											$infos = $effect->execute($monsterStats);
											$dmg = $infos[0];
											$debuff = array("perCent"=>$infos[1],"type"=>$infos[2],"turns"=>$infos[3]);
											$this->apply_skill_damage($dmg,$opposingTeam,$targetZone,$monsterStats,$monsterElmt,$debuff,false);
											break;
											
					case EFFECT::cleanse :
											// Get cleanse detail
											$nbDebuffToClean = $effect->execute();
											// TODO : gerer ciblage (unique, all)
											$this->apply_cleanse($playingTeam,$nbDebuffToClean);
					
				}
			}
		}
		
		
		
		
		// LEVEL 3 : Target the effect
		///////////////////////////////////////////////////////
		// Next functions choose the target(s) for skill effects
		
		// deal damage and optionnal debuff
		private function apply_skill_damage($dmg,$opposingTeam,$targetZone,$attackingMonsterStats,$attackingMonsterElmt,$debuff,$ignoreDef){
			switch($targetZone){
				case TARGET::UNIQUE :
										$nbMon = count($this->teams[$opposingTeam]);
										do{
											$id_target = mt_rand(0,$nbMon-1);
										}while ( $this->teams[$opposingTeam][$id_target] == null );
										$defMonster = $this->teams[$opposingTeam][$id_target];
										$targetKilled = $this->deal_damage($dmg,$defMonster,$attackingMonsterStats[STATS::CR],$attackingMonsterStats[STATS::CD],$attackingMonsterElmt,$ignoreDef);
										if ( $targetKilled ){
											$this->remove_monster($id_target,$opposingTeam);
										}else{
											if ( $debuff ){
												$this->apply_debuff($debuff,$defMonster,$attackingMonsterStats[STATS::PRE]);
											}
										}
										break;
										
				case TARGET::MULTI :
										break;
										
				case TARGET::ALL :		
										foreach ( $this->teams[$opposingTeam] as $id_target => $defMonster ){
											if ( $defMonster != null ){
												echo "<br> &nbsp; &nbsp; &nbsp; * ";
												$targetKilled = $this->deal_damage($dmg,$defMonster,$attackingMonsterStats[STATS::CR],$attackingMonsterStats[STATS::CD],$attackingMonsterElmt,$ignoreDef);
												if ( $targetKilled ){
													$this->remove_monster($id_target,$opposingTeam);
												}else{
													if ( $debuff ){
														$this->apply_debuff($debuff,$defMonster,$attackingMonsterStats[STATS::PRE]);
													}
												}
											}
										}
										break;
			}
		}
		
		// remove debuff from allies
		private function apply_cleanse($playingTeam,$nbDebuffToClean){
			
			// TODO : handle zone effect and choose target(s)
			
			foreach ( $this->teams[$playingTeam] as $mon){
				if ( $mon != null ){
					for ( $i=0; $i<$nbDebuffToClean; $i++ ){
						$mon->remove_debuff();
					}
				}
			}
		}
		
		
		
		
		// LEVEL 4 : Final level
		////////////////////////////////////////////////////////////////////////////
		// Next functions will finally apply a specific effect to a specific monster
		
		private function deal_damage ( $dmg, $defMonster, $criticalRate, $criticalDamages, $attackingMonsterElmt, $ignoreDef ){
			
			if ( $this->verbose ) echo "(dmg=".$dmg;
			
			// Critical ?
			if ( mt_rand(0,100) < $criticalRate ){
				$dmg *= ( 1 + $criticalDamages / 100 );
				if ( $this->verbose ) echo " +".$criticalDamages."%";
			}
			
			// Elemental advantage ?
			$adv = $this->has_advantage ( $attackingMonsterElmt, $defMonster->get_element() );
			if ( $adv == 1){
				$dmg *= 1.3;
				if ( $this->verbose ) echo " +30%";
			}elseif ( $adv == -1){
				$dmg *= 0.7;
				if ( $this->verbose ) echo " -30%";
			}
			
			// Defense
			$ennemyDef = $defMonster->get_fight_stats()[STATS::DEF];
			if ( $ignoreDef )	$ennemyDef = 0;
			$defFactor = 1000 / (1140 + 3.5*$ennemyDef);
			$dmg = round($dmg * $defFactor);
			if ( $this->verbose ) echo ") on ".$defMonster->get_name()." (x".round($defFactor,2).") => !".$dmg."!" ;
			
			// Hit
			if ( $defMonster->take_hit($dmg) ){
				// Monster survived damamges
				
				////////////////////////////////////////////////////////////////////////////////
				// TODO : check for counter-attack (if target has revenge rune, or counter buff)
				////////////////////////////////////////////////////////////////////////////////
				return false;
			}else{
				// Monster is dead
				if ( $this->verbose ) echo " dead";
				return true;
			}
		}
		
		private function apply_debuff($debuff,$defMonster,$accuracy){
			// Check Immunity
			/*foreach ( $defMonster->get_buff() as $buff ){
				if ( $buff["type"] == BUFF::IMMUNITY ) return;
			}*/
			// Check PRE/RES
			$ennemyRes = $defMonster->get_fight_stats()[STATS::RES];
			$chanceToResist = $ennemyRes - $accuracy;
			if ( $chanceToResist < 15 ) $chanceToResist = 15;
			$chanceToApply = (100-$chanceToResist) * $debuff["perCent"] / 100;
			if ( mt_rand(1,100) < $chanceToApply ){
				// Apply debuff
				if ( $this->verbose ) echo " apply ".DEBUFF::get_name($debuff["type"])." for ".$debuff["turns"]." turns";
				$defMonster->add_debuff($debuff);
			}
		}
		
		
		
		
		
		
		
		// When a monster die => move it from "team" array to "dead" array
		private function remove_monster($id,$team){
			$mon = $this->teams[$team][$id];
			$this->teamDeads[$team][$id] = $mon;
			$this->teams[$team][$id] = null;
			$this->speedCounter[$id+(10*($team-1))] = 0;
		}
		
		
		
		// UTILITY FUNCTIONS
		//////////////////////////////
		public function has_advantage($elmt1,$elmt2){
			//echo "has_advantage ( ".ELMT::get_name($elmt1).", ".ELMT::get_name($elmt2)." )<br>";
			if (
				($elmt1 == ELMT::water && $elmt2 == ELMT::fire) ||
				($elmt1 == ELMT::fire && $elmt2 == ELMT::wind) ||
				($elmt1 == ELMT::wind && $elmt2 == ELMT::water) ||
				($elmt1 == ELMT::dark && $elmt2 == ELMT::light) ||
				($elmt1 == ELMT::light && $elmt2 == ELMT::dark)
			){
				return 1;
			}elseif (
				($elmt1 == ELMT::water && $elmt2 == ELMT::wind) ||
				($elmt1 == ELMT::fire && $elmt2 == ELMT::water) ||
				($elmt1 == ELMT::wind && $elmt2 == ELMT::fire)
			){
				return -1;
			}else{
				return 0;
			}
		}
		
		public function get_winner(){
			for ( $idTeam=1; $idTeam<3; $idTeam++ ){
				if ( count($this->teams[$idTeam]) == count($this->teamDeads[$idTeam]) ) return $idTeam % 2 + 1;
			}
			return 0;
		}
		
		public function display_team ( $team ){
			echo "<div class='team'>";
			$speedBar = 0;
			
			$nbMon = count($this->teams[$team]) + count($this->teamDeads[$team]);
			for ( $i=0; $i<$nbMon; $i++ ){
				$mon = $this->teams[$team][$i];
				if ( $mon != null ){
					$mon->display_infight($this->speedCounter[$i]);
				}else{
					echo "<div class='infightMonster'><table style='opacity:0;'><tr><td>&nbsp;</td></tr></table></div>";
				}
			}
			echo "</div>";
		}
	
		public function display(){
			echo "<div class='fight'><table><tr><td>";
			$this->display_team(1);
			echo "</td></tr><tr><td style='text-align:center'>VS</td></tr><tr><td>";
			$this->display_team(2);
			echo "</td></tr></table></div>";
		}
	}
	
	
	
?>
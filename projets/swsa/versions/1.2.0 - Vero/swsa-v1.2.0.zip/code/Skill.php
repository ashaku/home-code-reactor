<?
	// Skill Classes
	// Represent any monster skill
	// It has a list of effects
	// Effects are basic action : deal damage, heal, buff, debuff, etc
	
	class Skill{
		private $name;
		private $effects;	// SkillAction
		private $cooldown;	// int
		private $active;	// bool
	
		function __construct($aNom,$aEffects,$aCooldown,$aActive) {
			$this->name = $aNom;
			$this->effects = $aEffects;
			$this->cooldown = $aCooldown;
			$this->active = $aActive;
		}
		public function get_name(){			return $this->name;		}
		public function get_effects(){		return $this->effects;	}
		public function get_cooldown(){		return $this->cooldown;	}
		public function is_active(){		return $this->active;	}
	}
	
	
	class SkillEffect{
		private $type;
		private $targetSide; 	// 0:ennemy ; 1:ally
		private $targetZone; // 0:unique ; 1:multi ; 2:all
		
		function __construct($aType,$aSide,$aZone) {
			$this->type = $aType;
			$this->targetSide = $aSide;
			$this->targetZone = $aZone;
		}
		
		public function get_type(){	return $this->type;	}
		public function get_targetSide(){	return $this->targetSide;	}
		public function get_targetZone(){	return $this->targetZone;	}
		public function execute(){}
	}
	
	class Damage extends SkillEffect{
		private $formula;
		private $nbHits;
		
		function __construct($aZone,$aFormula,$aType=EFFECT::damage,$aNbHits=1){
			parent::__construct($aType,0,$aZone);
			$this->formula = $aFormula;
			$this->nbHits = $aNbHits;
		}
		
		public function execute($attackingMonsterStats){
			// decode formula
			$operand1 = 0;
			$operand2 = 0;
			$operator1 = "";
			$operator2 = "";
			$total = 0;
			//echo "<br><br>Start Decode Formula : ";print_r($this->formula);
			foreach($this->formula as $i => $line){
				//echo "<br> &nbsp; line $i : ";print_r($line);
				
				// for operand
				if ( $i % 2 == 0 ){
					
					// If unique value
					if ( count($line) == 1 ){
						// decode stat
						$data = $line[0];
						//echo "<br> &nbsp; Unique value : ".$data;
						if ( !is_numeric($data) ){
							switch($data){
								case "HP": $lineVal = $attackingMonsterStats[STATS::HP];	break;
								case "ATK": $lineVal = $attackingMonsterStats[STATS::ATK];	break;
								case "DEF": $lineVal = $attackingMonsterStats[STATS::DEF];	break;
								case "SPD": $lineVal = $attackingMonsterStats[STATS::SPD];	break;
								case "MAXHP": $lineVal = $attackingMonsterStats[STATS::MAXHP];	break;
							}
							//echo " => ".$lineVal;
						}else{
							$lineVal = $data;
						}
						
						
					// If operand is formula itself : apply same logic on a second level
					}else{
						
						$lineVal = 0;
						//echo "<br> &nbsp; Array value : compute";
						foreach($line as $j => $data){
							//echo "<br> &nbsp; &nbsp; $j. $data";
							
							if ( $j % 2 == 0 ){
								//operand
								//decode stat
								if ( !is_numeric($data) ){
									switch($data){
										case "HP": $numval = $attackingMonsterStats[STATS::HP];		break;
										case "ATK": $numval = $attackingMonsterStats[STATS::ATK];	break;
										case "DEF": $numval = $attackingMonsterStats[STATS::DEF];	break;
										case "SPD": $numval = $attackingMonsterStats[STATS::SPD];	break;
										case "MAXHP": $numval = $attackingMonsterStats[STATS::MAXHP];	break;
									}
									//echo " => ".$numval;
								}else{
									$numval = $data;
								}
								if ( $j == 0 ){
									//store first
									$lineVal = $numval;
									//echo " :: Store $numval as first subline value";
								}else{
									//calculate next
									//echo " :: Compute $lineVal ";
									switch ($operator2){
										case "+": $lineVal += $numval; break;
										case "-": $lineVal -= $numval; break;
										case "*": $lineVal *= $numval; break;
										case "/": $lineVal /= $numval; break;
										case "%": $lineVal = $lineVal * $numval / 100; break;
									}
									//echo " => $lineVal";
								}
							}else{
								$operator2 = $data;
								//echo " :: update operator2";
							}
						}
					}
					
					// If first value
					if ( $i == 0 ){
						
						// store
						$total = $lineVal;
						//echo "<br> &nbsp; Store $lineVal as first line value";
					}else{
						
						// For next values : update total with last operand and current operand
						//echo "<br> &nbsp; Compute $total ";
						switch ($operator1){
							case "+": $total += $lineVal; break;
							case "-": $total -= $lineVal; break;
							case "*": $total *= $lineVal; break;
							case "/": $total /= $lineVal; break;
							case "%": $total = $total * $lineVal / 100; break;
						}
						//echo " => $total";
					}
				
				// for operator
				}else{
					// simply store it
					$operator1 = $line[0];
					//echo " update operator1";
				}
			}
			//echo "<br> => total damage : ".round ( $total );
			return round ( $total );
		}
	}
	
	class DamageDebuff extends Damage{
		private $debuffType;
		private $nbTurns;
		private $perCent;
		
		function __construct($aZone,$aFormula,$aDebuffType,$aNbTurns,$aPerCent,$aNbHits=1){
			parent::__construct($aZone,$aFormula,EFFECT::damageDebuff,$aNbHits);
			$this->debuffType = $aDebuffType;
			$this->nbTurns = $aNbTurns;
			$this->perCent = $aPerCent;
		}
		
		public function execute($attackingMonsterStats){
			$dmg = parent::execute($attackingMonsterStats);
			return array($dmg,$this->perCent,$this->debuffType,$this->nbTurns);
		}
	}
	
	
	
	class Cleanse extends SkillEffect{
		private $nbDebuffToClean;	// 0:all ; n:n
		
		function __construct($aZone,$aNbDebuff){
			parent::__construct(EFFECT::cleanse,1,$aZone);
			$this->nbDebuffToClean = $aNbDebuff;
		}
		
		public function execute(){
			return $this->nbDebuffToClean;
		}
	}
	
	
	abstract class SkillLib{
		public function load_skill ( $name ){
			switch($name){
				case "MegaSmash":
					$skillName = "Mega Smash";
					$targetZone = TARGET::UNIQUE;
					$dmgFormula = array(array("SPD","+",210),array("/"),array(0.7),array("%"),array("ATK"));
					$nbHits = 1;
					$debuffType = DEBUFF::CONSTDMG;
					$nbTurns = 2;
					$perCent = 50;
					$constDamageEffect = new DamageDebuff($targetZone,$dmgFormula,$debuffType,$nbTurns,$perCent,$nbHits);
					$skillEffects = array($constDamageEffect);
					$skillCooldown = 1;
					$active = true;
					break;
					
				case "SuperCrush":
					$skillName = "Super Crush";
					$targetZone = TARGET::ALL;
					$dmgFormula = array(array(16,"%","MAXHP"),array("+"),array(120,"%","ATK"));
					$debuffType = DEBUFF::STUN;
					$nbTurns = 1;
					$perCent = 30;
					$StunDamageEffect = new DamageDebuff($targetZone,$dmgFormula,$debuffType,$nbTurns,$perCent,$nbHits);
					$skillEffects = array($StunDamageEffect);	// SkillAction
					$skillCooldown = 4;
					$active = true;
					break;
					
				case "ConversionOfMagic":
					$skillName = "Conversion of Magic";
					$targetZone = TARGET::ALL;
					$nbCleanse = 1;		// 0:all ; n:n
					$cleanseEffect = new Cleanse($targetZone,$nbCleanse);
					$skillEffects = array($cleanseEffect);	// SkillAction
					$skillCooldown = 1;
					$active = false;
					break;
				
				
				/* SAMPLE :
				case "" :
					$skillName = "";
					$effect = new _effect_();
					$skillEffects = array($effect);
					$skillCooldown = 1;
					$active = true;
					break;
					*/
			}
			return new Skill($skillName,$skillEffects,$skillCooldown,$active);
		}
	}
?>
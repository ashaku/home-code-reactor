<?
	include ("constants.php");
	include ("Skill.php");
	include ("Rune.php");
	include ("Combat.php");
	
	class Monster{
		
		private $name;
		private $element;			// ELMT
		private $baseStats;			// array(STATS)
		private $runes;				// Runage
		private $runeModifiers;		// array(STATS)
		private $runeStats;			// baseStat + runeModifiers + leadSkill : default stats at start of fight
		private $buffList;			// array(BUFF)
		private $debuffList;		// array(DEBUFF)
		private $buffModifiers;		// array(STATS)
		private $fightStats;		// runeStat + buffModifiers
		//private $maxHP;				// int
		private $skills;			// Array(SKILL)
		private $leaderSkill;		// Bonus
		private $cooldowns;			// array(int)
		
		function __construct($aNom,$aElement,$aStats,$aCodeRunes,$aSkills,$aLead) {
			
			// copy given datas
			$this->name = $aNom;
			if ( $aElement >= 0 && $aElement <= 5 ){
				$this->element = $aElement;
			}
			if ( sizeof($aStats) == 8 ){
				$this->baseStats = $aStats;
			}
			for ( $i=0; $i<=3; $i++ ){
				if ( $aSkills[$i] ){
					$this->skills[$i] = $aSkills[$i];
					$this->cooldowns[$i] = 0;
				}
			}
			$this->leaderSkill = $aLead;
			
			// Calculate rune stats modifiers
			$runage = new Runage($aCodeRunes);
			$this->runes = $runage;
			$this->runeModifiers = array();
			$this->calculate_runes_modifiers();
			
			// Init other members
			$this->buffList = array();
			$this->debuffList = array();
			$this->buffModifiers = array();
			$this->fightStats = $this->runeStats;
			$this->fightStats[8] = $this->runeStats[0];
		}
		
		// Getters
		public function get_name(){				return $this->name;				}
		public function get_element(){			return $this->element;			}
		public function get_base_stats(){		return $this->baseStats;		}
		public function get_base_stat($stat){	return $this->baseStats[$stat];	}
		public function get_skills(){			return $this->skills;			}
		public function get_skill($id){			return $this->skills[$id];		}
		public function get_leadSkill(){		return $this->leaderSkill;		}
		public function get_runes_mod(){		return $this->runeModifiers;	}
		public function get_runes_stats(){		return $this->runeStats;		}
		public function get_runes_stat($stat){	return $this->runeStats[$stat];	}
		public function get_fight_stats(){		return $this->fightStats;		}
		public function get_fight_stat($stat){	return $this->fightStats[$stat];}
		public function get_buffs(){			return $this->buffList;			}
		public function get_debuffs(){			return $this->debuffList;		}
		public function get_buff_mod(){			return $this->buffModifiers;	}
		public function get_cooldowns(){		return $this->cooldowns;		}
		
		// Aggregate bonus from runage (family + sub)
		private function calculate_runes_modifiers(){
			$this->runeModifiers = array(0,0,0,0,0,0,0,0);
			// Each runageSubBonus
			$i = 0;
			foreach($this->runes->get_stats_modifiers() as $mod){
				$s = floor($i/2);
				if ( $i % 2 == 0 || $s > 3 ){
					$this->runeModifiers[$s] += $mod;
				}else{
					$pc = round( $mod * $this->baseStats[$s] / 100 );
					$this->runeModifiers[$s] += $pc;
				}
				$i++;
			}
			// Each runageFamilyBonus
			$i = 0;
			foreach($this->runes->get_family_modifiers() as $mod){
				$s = floor($i/2);
				if ( $i % 2 == 0 || $i > 3 ){
					$this->runeModifiers[$s] += $mod;
				}else{
					$pc = round( $mod * $this->baseStats[$s] / 100 );
					$this->runeModifiers[$s] += $pc;
				}
				$i++;
			}
			
			// Update runeStats (base + runes)
			for ( $i=0; $i<8; $i++ ){
				$v = $this->baseStats[$i] + $this->runeModifiers[$i];
				if ( ($i==STATS::CR || $i==STATS::PRE || $i==STATS::RES) && $v > 100 ) $v = 100;
				$this->runeStats[$i] = $v;
				$this->buffModifiers[$i] = 0;
			}
		}
		
		
		public function display(){
			echo "
				<div class='monsterID'>
					<b>".$this->name."</b><br>
					<span>(".ELMT::get_name($this->element).")</span>
					<br><br>
					<table cellspacing=0 border=0 width=100%>";
			// Stats
			for ($i=0;$i<4;$i++){
				echo "
					<tr>
						<td title='".STATS::get_long_name($i)."' class='statName'>".STATS::get_short_name($i)."</td><td class='statVal'>".$this->baseStats[$i]."</td><td class='statMod'>+".$this->runeModifiers[$i]."</td>
						<td title='".STATS::get_long_name($i+4)."' class='statName'>".STATS::get_short_name($i+4)."</td><td class='statVal'>";
						$v = $this->baseStats[$i+4]+$this->runeModifiers[$i+4];
						if ( $i != 1 && $v > 100 ) $v = 100;
						echo "$v</td><td class='statMod'>&nbsp;</td>
					</tr>";
			}
			echo "
					</table>
					<br><br>";
			
			// Skills
			echo "
					<div class='skills'>";
			foreach ( $this->skills as $skill){
				echo "
						<span>".$skill->get_name()."</span>";
			}
			echo "
					</div><br><br>";
			
			// Runes
			$this->runes->display();
			echo"
				</div>";
		}
		public function display_infight($speedBar){
			$currentHP = $this->fightStats[STATS::HP];
			$maxHP = $this->fightStats[STATS::MAXHP];
			$perCentHP = round( $currentHP * 100 / $maxHP );
			$mainStats = "";
			foreach ( $this->runes->get_main_stats() as $st ){	$mainStats .= STATS::get_short_name($st). " / ";	}
			$mainStats = substr($mainStats,0,-3);
			$families = "";
			foreach ( $this->runes->get_families() as $family ){$families .= RUNEFAMILY::get_name($family)." "; }
			$buffsdebuffs = "";
			foreach ( $this->debuffList as $debuff ){	$buffsdebuffs .= "<div class='debuff' title='".DEBUFF::get_name($debuff["type"])."'>".$debuff["turns"]."</div>";	}
			foreach ( $this->buffList as $buff ){		$buffsdebuffs .= "<div class='buff' title='".BUFF::get_name($buff["type"])."'>".$buff["turns"]."</div>";	}
			
			echo "<div class='infightMonster ".ELMT::get_name($this->element)."'>";
			echo "	<div class='name'>".$this->name."</div>";
			echo "	<div class='runesBonus'>".$families."<br>".$mainStats."</div>";
			
			echo "	<div class='buffDebuff'>".$buffsdebuffs."</div>";
			
			echo "	<table cellspacing=1><tr><td class='remainingHP' width='".$perCentHP."%' title='$currentHP / $maxHP'></td><td class='emptyBar' title='$currentHP / $maxHP'></td></tr></table>";
			//echo "	<tr><td colspan=2 style='font-size:11px;'>".$currentHP." / ".$this->maxHP."</td></tr></table>";
			
			if ( $speedBar > 100 ) $speedBar = 100;
			echo "	<table cellspacing=1><tr><td class='AttackBar' width='".$speedBar."%'></td><td class='emptyBar'></td></tr></table>";
			
			echo "</div>";
		}
		
		////////////////////////////////////////////////////////////
		//////////////////// COMBAT ////////////////////////////////
		////////////////////////////////////////////////////////////
		
		
		// The leader skill bonus is aggregated to runes bonus. FightStats are recalculated
		// This function should be called at fight start, so we can assume there are no buff modifiers and fightStat = runeStat
		public function add_leader_skill_bonus ( $leadSkill ){
			
			// Decode bonus
			$leadSkillStat = $leadSkill->get_stat();
			$leadSkillType = $leadSkill->get_type();
			$leadSkillValue = $leadSkill->get_value();
			if ( $leadSkillType == 1 ){
				$statDelta = round($this->get_base_stat($leadSkillStat) * $leadSkillValue / 100);
			}else{
				$statDelta = $leadSkillValue;
			}
			
			// Calculate new stat value
			$v = $this->baseStats[$leadSkillStat] + $this->runeStats[$leadSkillStat] + $statDelta;
			if ( ($leadSkillStat==STATS::CR || $leadSkillStat==STATS::PRE || $leadSkillStat==STATS::RES) && $v > 100 ) $v = 100;
			
			// Update stat value
			$this->runeStats[$leadSkillStat] = $v;
			$this->fightStats[$leadSkillStat] = $v;
			
			// 
			if ( $leadSkillStat == STATS::HP ){
				$this->fightStats[8] = $v;
			}
		}
		
		
		// Choose a skill
		// You can specify skill index (advanced user) or let the monster choose one available skill at random
		public function choose_skill($skillId=null){
			if ( $skillId == null ) $skillId = $this->choose_skill_id();
			$this->cooldowns[$skillId] = $this->skills[$skillId]->get_cooldown();
			return $this->skills[$skillId];
		}
		public function choose_skill_id(){
			$tabSkill = array();
			//$nbSkillAvailable = 0;
			foreach ( $this->cooldowns as $id => $cd ){
				if ( $cd==0 && $this->skills[$id]->is_active() ){
					array_push($tabSkill,$id);
					//$nbSkillAvailable++;
				}
			}
			$nbSkillAvailable = count($tabSkill);
			if ( $nbSkillAvailable > 1 ){
				return $tabSkill[mt_rand(0,$nbSkillAvailable-1)];
			}else{
				return $tabSkill[0];
			}
		}
		
		// Decrease skills cooldown
		public function cooldown(){
			// Skills
			for ( $i=0; $i<5; $i++ ){
				$cd = $this->cooldowns[$i];
				if ( $cd > 0 )
					$this->cooldowns[$i] = $cd - 1;
			}
			// active buffs
			foreach ( $this->buffList as $k => $buff ){
				if ( $buff["turns"] > 1 ){
					$this->buffList[$k]["turns"] -= 1;
				}else{
					$this->remove_buff($buff);
				}
			}
			// active debuffs
			foreach ( $this->debuffList as $k => $debuff ){
				if ( $debuff["turns"] > 1 ){
					$this->debuffList[$k]["turns"] -= 1;
				}else{
					// apply bomb affect here
					$this->remove_debuff($debuff);
				}
			}
		}
		
		// When the monster is hit. Rturn true if he's still alive after
		public function take_hit ( $dmg ){
			//echo $this->fightStats[STATS::HP];
			$this->fightStats[STATS::HP] -= $dmg;
			//echo "->".$this->fightStats[STATS::HP]." ";
			if ( $this->fightStats[STATS::HP] > 0 ) return true;
			return false;
		}
		
		
		
		// BUFF
		public function add_buff($buff){
			// Check if buff is already on monster => don't add but refresh nbTurns
			foreach($this->get_buffs() as $k=>$mybuff){
				if ( $mybuff["type"] == $buff["type"] ){
					$this->buffList[$k]["turns"] = $buff["turns"];
					return true;
				}
			}
			// Check number of buffs. If more than 10 => replace older buff by new one
			if ( count($this->buffList) > 9 ){
				array_shift($this->buffList);
			}
			array_push($this->buffList,$buff);
			
			// If new debuff is about stats : update fightStats
			$this->update_buffModifiers(1,1,$buff);
		}
		
		// DEBUFF
		public function add_debuff($debuff){
			// Check if debuff is already on monster => don't add but refresh nbTurns (except for CONST DMG)
			foreach($this->get_debuffs() as $k=>$mydebuff){
				if ( $mydebuff["type"]==$debuff["type"] && $debuff["type"]!=DEBUFF::CONSTDMG ){
					$this->debuffList[$k]["turns"] = $debuff["turns"];
					return true;
				}
			}
			// Check number of debuffs. If more than 10 => replace older debuff by new one (except for CONST DMG)
			if ( count($this->debuffList)>9 && $debuff["type"]!=DEBUFF::CONSTDMG ){
				array_shift($this->debuffList);
			}
			
			// Add debuff on monster
			array_push($this->debuffList,$debuff);
			
			// If new debuff is about stats : update buff modifiers (and fightStats)
			$this->update_buffModifiers(1,0,$debuff);
		}
		
		// CLEANSE
		public function remove_debuff(){
			if ( count($this->debuffList) > 0 ){
				$debuff = array_shift($this->debuffList);
				$this->update_buffModifiers(0,0,$debuff);
			}
		}
		
		// STRIP
		public function remove_buff(){
			if ( count($this->buffList) > 0 ){
				$buff = array_shift($this->buffList);
				$this->update_buffModifiers(0,1,$buff);
			}
		}
		
		
		
		// When buffing/debuffing : update buff modifiers and fightStats
		// $add : 	0:removed ; 1:added
		// isBuff : 0:debuff ; 1:buff
		private function update_buffModifiers ( $add, $isBuff, $buffOrDebuff){
			if ( $add ){
				if ($isBuff){
					// buff was added : add according value
					switch($buffOrDebuff["type"]){
						case BUFF::RAISEATK : 	$this->set_buffModifier(STATS::ATK,$this->get_runes_stat(STATS::ATK) * 0.5); break;
						case BUFF::RAISEDEF : 	$this->set_buffModifier(STATS::DEF,$this->get_runes_stat(STATS::DEF) * 0.7); break;
						case BUFF::RAISESPD : 	$this->set_buffModifier(STATS::SPD,$this->get_runes_stat(STATS::SPD) * 0.3); break;
						case BUFF::RAISECR : 	$this->set_buffModifier(STATS::CR,30); break;
					}
				}else{
					// debuff was added : substract according value
					switch($buffOrDebuff["type"]){
						case DEBUFF::LOWATK : 	$this->set_buffModifier(STATS::ATK,$this->get_runes_stat(STATS::ATK) * -0.5); break;
						case DEBUFF::LOWDEF : 	$this->set_buffModifier(STATS::DEF,$this->get_runes_stat(STATS::DEF) * -0.7); break;
						case DEBUFF::LOWSPD : 	$this->set_buffModifier(STATS::SPD,$this->get_runes_stat(STATS::SPD) * -0.3); break;
					}
				}
			}else{
				if ($isBuff){
					// buff was removed : substract what it needs to get back to original stat
					switch($buffOrDebuff["type"]){
						case BUFF::RAISEATK : 	$this->set_buffModifier(STATS::ATK,$this->get_runes_stat(STATS::ATK) * -0.5); break;
						case BUFF::RAISEDEF : 	$this->set_buffModifier(STATS::DEF,$this->get_runes_stat(STATS::DEF) * -0.7); break;
						case BUFF::RAISESPD : 	$this->set_buffModifier(STATS::SPD,$this->get_runes_stat(STATS::SPD) * -0.3); break;
						case BUFF::RAISECR : 	$this->set_buffModifier(STATS::CR,-30); break;
					}
				}else{
					// debuff was removed : add what it needs to get back to original stat
					switch($buffOrDebuff["type"]){
						case DEBUFF::LOWATK : 	$this->set_buffModifier(STATS::ATK,$this->get_runes_stat(STATS::ATK) * 0.5); break;
						case DEBUFF::LOWDEF : 	$this->set_buffModifier(STATS::DEF,$this->get_runes_stat(STATS::DEF) * 0.7); break;
						case DEBUFF::LOWSPD : 	$this->set_buffModifier(STATS::SPD,$this->get_runes_stat(STATS::SPD) * 0.3); break;
					}
				}
			}
		}
		
		// Update the buff modifieres array
		public function set_buffModifier ( $stat, $value ){
			$newModifier = $this->buffModifiers[$stat] + round($value);
			$this->buffModifiers[$stat] = $newModifier;
			$newStat = $this->runeStats[$stat] + $newModifier;
			if ( ($stat==STATS::CR || $stat==STATS::PRE || $stat==STATS::RES) && $newStat > 100 ) $newStat = 100;
			$this->fightStats[$stat] = $newStat;
		}
		
		
		
		
		
		// Check if monster has constant damage debuff and apply it
		public function apply_constant_damages(){
			$nbConstDmg = 0;
			foreach($this->get_debuffs() as $debuff){
				if ( $debuff["type"] == DEBUFF::CONSTDMG ){
					$this->fightStats[STATS::HP] -= round($this->fightStats[STATS::MAXHP] * 0.05);
					$nbConstDmg++;
				}
			}
			return $nbConstDmg;
		}
		
		// Check if monster has heal buff and apply it
		public function apply_heal_buff(){
			foreach($this->get_buffs() as $buff){
				if ( $buff["type"] == BUFF::HEAL ){
					
					// TODO : check if mob has unrecoverable debuff (DEBUFF::NOHEAL)
					
					$maxHP = $this->fightStats[STATS::MAXHP];
					$heal = round($maxHP * 0.15);
					$newHP = $this->fightStats[STATS::HP] + $heal;
					if ( $newHP > $maxHP )	$newHP = $maxHP;
					$this->fightStats[STATS::HP] = $newHP;
					return true;
				}
			}
			return false;
		}
		
		// Check if monster is Stun, asleep or frozen
		public function isReady(){
			foreach($this->get_debuffs() as $debuff){
				if ( $debuff["type"]==DEBUFF::STUN || $debuff["type"]==DEBUFF::ASLEEP || $debuff["type"]==DEBUFF::FREEZE ){
					return false;
				}
			}
			return true;
		}
	}
	
	
	
	// Monster Factory : just ask by name and you will receive
	abstract class MonsterLib{
		public function load_monster($name,$runeCode){
			switch ( $name ){
				case "Veromos":
					$element = ELMT::dark;
					$megaSmash = SkillLib::load_skill("MegaSmash");
					$superCrush = SkillLib::load_skill("SuperCrush");
					$convMagic = SkillLib::load_skill("ConversionOfMagic");
					$skills = array($megaSmash,$superCrush,$convMagic);
					$leaderSkill = new Bonus(STATS::HP,1,33);
					$stats = array(9225,769,758,100,15,50,0,15);
					break;
		
			}
			return new Monster($name,$element,$stats,$runeCode,$skills,$leaderSkill);
		}
	}
?>